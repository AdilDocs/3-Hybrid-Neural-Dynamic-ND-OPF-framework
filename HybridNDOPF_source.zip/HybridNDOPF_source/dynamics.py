"""Multi-machine transient-stability simulation (phasor / RMS domain).

Two fidelity levels share the same Kron-reduced network:
  * 'classical' : 2nd-order swing model, constant E' behind x'_d
  * 'flux'      : 4-state model per machine = swing + flux-decay (one-axis, x'_q = x'_d)
                  + static AVR/exciter with limits. Used as the high-fidelity
                  "ground-truth" simulator in all evaluations.

Corrected swing equation (per-unit speed deviation Δω, angle in rad):
    dδ/dt   = ω_b · Δω
    dΔω/dt  = (P_m − P_e − D·Δω) / (2H)
States are always reported as deviations w.r.t. the centre of inertia (COI).
"""
import numpy as np
import scipy.sparse as sp
from scipy.sparse.csgraph import connected_components
from pypower.makeYbus import makeYbus
from pypower.idx_brch import BR_STATUS

OMEGA_B = 2 * np.pi * 60.0

# Standard 10-machine New England data (Pai 1989; H in s, reactances in pu on 100 MVA)
NE39 = {  # gen bus (1-based ext.) : (H, x'd, xd, T'do)
    30: (42.0, 0.031, 0.100, 10.2), 31: (30.3, 0.0697, 0.295, 6.56),
    32: (35.8, 0.0531, 0.2495, 5.70), 33: (28.6, 0.0436, 0.262, 5.69),
    34: (26.0, 0.132, 0.670, 5.40), 35: (34.8, 0.050, 0.254, 7.30),
    36: (26.4, 0.049, 0.295, 5.66), 37: (24.3, 0.057, 0.290, 6.70),
    38: (34.5, 0.057, 0.2106, 4.79), 39: (500.0, 0.006, 0.020, 7.00),
}


class MachineData:
    def __init__(self, grid, damping_ratio=0.5, KA=25.0, TA=0.05, Efd_max=5.0):
        ng = grid.ng
        if grid.name == "case39":
            ext = grid.ppc["order"]["bus"]["i2e"][grid.gbus].astype(int)
            arr = np.array([NE39[int(b)] for b in ext])
            self.H, self.xdp, self.xd, self.Tdo = arr.T
        else:
            # IEEE-118 has no standard dynamic data set: typical parameters scaled
            # by machine rating S (MVA) and expressed on the 100 MVA system base.
            S = np.maximum.reduce([grid.Pmax * grid.base * 1.1,
                                   np.abs(grid.Qmax) * grid.base * 1.1,
                                   np.full(ng, 50.0)])
            self.H = 4.0 * S / grid.base
            self.xdp = 0.30 * grid.base / S
            self.xd = 1.80 * grid.base / S
            self.Tdo = np.full(ng, 6.0)
        self.D = damping_ratio * 2 * self.H      # D/(2H) = damping_ratio [1/s]
        self.KA, self.TA, self.Efd_max = KA, TA, Efd_max
        self.M = 2 * self.H


# --------------------------------------------------------------------------
# Network reduction
# --------------------------------------------------------------------------
def _ybus_without(grid, line):
    br = grid.ppc["branch"].copy()
    br[line, BR_STATUS] = 0
    Y, _, _ = makeYbus(grid.base, grid.ppc["bus"], br)
    return sp.csr_matrix(Y)


def kron_reduce(Ybus, yload, yg, gbus, fault_bus=None):
    """Reduced admittance seen from generator internal nodes."""
    Ynn = Ybus.toarray().astype(complex)
    Ynn[np.diag_indices_from(Ynn)] += yload
    Ynn[gbus, gbus] += yg
    if fault_bus is not None:
        Ynn[fault_bus, fault_bus] += 1e7  # bolted three-phase fault
    Ygn = np.zeros((len(gbus), Ynn.shape[0]), complex)
    Ygn[np.arange(len(gbus)), gbus] = -yg
    return np.diag(yg) - Ygn @ np.linalg.solve(Ynn, Ygn.T)


def connected_after_removal(grid, line):
    keep = np.ones(grid.nl, bool)
    keep[line] = False
    A = sp.coo_matrix((np.ones(keep.sum()), (grid.f[keep], grid.t[keep])), shape=(grid.nb, grid.nb))
    return connected_components(A, directed=False)[0] == 1


class Contingency:
    """Three-phase bolted fault at `bus`, cleared after `tc` s by tripping `line`."""

    def __init__(self, grid, bus, line, tc):
        self.bus, self.line, self.tc = int(bus), int(line), float(tc)
        self.Ypost_bus = _ybus_without(grid, line)

    def __repr__(self):
        return f"Fault@bus{self.bus}/trip-line{self.line}/tc={self.tc}"


def candidate_contingencies(grid, tc):
    out = []
    for l in range(grid.nl):
        if not connected_after_removal(grid, l):
            continue
        for b in (grid.f[l], grid.t[l]):
            out.append((int(b), l))
    return [Contingency(grid, b, l, tc) for b, l in sorted(set(out))]


# --------------------------------------------------------------------------
# Initialisation from an AC power-flow state
# --------------------------------------------------------------------------
def init_machines(grid, md, st, Pd, Qd):
    V = st["V"]
    Vt = V[grid.gbus]
    Ig = np.conj((st["Pg"] + 1j * st["Qg"]) / Vt)
    E = Vt + 1j * md.xdp * Ig
    delta = np.angle(E)
    Eq = np.abs(E)
    Idq = Ig * np.exp(-1j * (delta - np.pi / 2))
    Efd = Eq + (md.xd - md.xdp) * Idq.real
    Vref = np.abs(Vt) + Efd / md.KA
    yload = (Pd - 1j * Qd) / np.abs(V) ** 2
    return dict(delta=delta, Eq=Eq, Efd=Efd, Vref=Vref, Pm=st["Pg"].copy(), yload=yload)


def reduced_matrices(grid, md, init, conts):
    yg = 1.0 / (1j * md.xdp)
    Ypre = kron_reduce(grid.Ybus, init["yload"], yg, grid.gbus)
    if not conts:
        return Ypre, None, None
    Yf = np.stack([kron_reduce(grid.Ybus, init["yload"], yg, grid.gbus, c.bus) for c in conts])
    Yp = np.stack([kron_reduce(c.Ypost_bus, init["yload"], yg, grid.gbus) for c in conts])
    return Ypre, Yf, Yp


# --------------------------------------------------------------------------
# Time-domain simulation (batched over contingencies)
# --------------------------------------------------------------------------
def simulate(grid, md, st, Pd, Qd, conts, model="flux", T=3.0, dt=0.005, record=False):
    """Returns dict with max COI angle deviation per contingency (rad), stable flags
    and optionally full trajectories."""
    init = init_machines(grid, md, st, Pd, Qd)
    Ypre, Yf, Yp = reduced_matrices(grid, md, init, conts)
    K, ng = len(conts), grid.ng
    tc = np.array([c.tc for c in conts])
    x = np.zeros((K, 4, ng))
    x[:, 0] = init["delta"]
    x[:, 2] = init["Eq"]
    x[:, 3] = init["Efd"]
    Mt = md.M.sum()

    def f(x, Y):
        d, w, Eq, Efd = x[:, 0], x[:, 1], x[:, 2], x[:, 3]
        E = Eq * np.exp(1j * d)
        I = np.einsum("kij,kj->ki", Y, E)
        Pe = (E * np.conj(I)).real
        dx = np.empty_like(x)
        dx[:, 0] = OMEGA_B * w
        dx[:, 1] = (init["Pm"] - Pe - md.D * w) / md.M
        if model == "flux":
            Id = (I * np.exp(-1j * (d - np.pi / 2))).real
            Vt = np.abs(E - 1j * md.xdp * I)
            dx[:, 2] = (Efd - Eq - (md.xd - md.xdp) * Id) / md.Tdo
            dEfd = (md.KA * (init["Vref"] - Vt) - Efd) / md.TA
            dEfd = np.where((Efd >= md.Efd_max) & (dEfd > 0), 0, dEfd)
            dEfd = np.where((Efd <= 0) & (dEfd < 0), 0, dEfd)
            dx[:, 3] = dEfd
        else:
            dx[:, 2] = 0
            dx[:, 3] = 0
        return dx

    nsteps = int(round(T / dt))
    max_dev = np.zeros(K)
    traj = [] if record else None
    for n in range(nsteps):
        t = n * dt
        Y = np.where((t < tc - 1e-9)[:, None, None], Yf, Yp)
        k1 = f(x, Y); k2 = f(x + 0.5 * dt * k1, Y); k3 = f(x + 0.5 * dt * k2, Y); k4 = f(x + dt * k3, Y)
        x = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        if model == "flux":
            x[:, 3] = np.clip(x[:, 3], 0, md.Efd_max)
        coi = (x[:, 0] * md.M).sum(1) / Mt
        dev = np.abs(x[:, 0] - coi[:, None]).max(1)
        max_dev = np.maximum(max_dev, dev)
        if record:
            traj.append(x.copy())
        if not record and np.all(max_dev > np.pi):
            break
    out = dict(max_dev=max_dev, stable=max_dev < np.pi, init=init)
    if record:
        tr = np.array(traj)  # (T, K, 4, ng)
        coi = (tr[:, :, 0] * md.M).sum(-1) / Mt
        out.update(t=dt * (1 + np.arange(len(tr))), traj=tr, coi=coi, Ypre=Ypre, Yf=Yf, Yp=Yp)
    return out


def coherence(max_dev):
    """Rotor-angle coherence index ρ_δ = max_t max_g |δ_g − δ_COI| (rad)."""
    return max_dev


def tsi(max_dev):
    """Transient stability index in (−1, 1]; >0 stable (COI-referenced, 180° limit)."""
    return (np.pi - max_dev) / (np.pi + max_dev)
