"""Train dispatch predictors.
usage: python train_predictor.py case39 --model gnn --label tsc --lam_pf 0.1 --lam_stab 1.0 --tag proposed
"""
import argparse
import time
import json
import numpy as np
import torch
from prep import Bundle
from models import BusGNN, MLPPredictor, Surrogate, steady_state, electrical_power, soft_max_dev
from tscopf import DELTA_LIM
from config import ROOT, OUT

DELTA_TARGET = DELTA_LIM - 0.3   # aim inside the security limit
TAU = 0.1


def sel(d, idx):
    return {k: (tuple(x[idx] for x in v) if isinstance(v, tuple) else v[idx]) for k, v in d.items()}


def stability_penalty(sur, Pg, dyn, slack, tc, T=1.5, dt=0.02):
    """Surrogate-based transient-security penalty for predicted dispatch Pg (B, ng)."""
    d = steady_state(Pg, dyn["e0"], *dyn["Ypre"], dyn["delta0"], slack)
    Pm, _ = electrical_power(d, dyn["e0"], *dyn["Ypre"])
    out = sur.simulate(d, dyn["e0"], Pm, dyn["Ypre"], dyn["Yf"], dyn["Yp"], tc, T=T, dt=dt)
    smax = soft_max_dev(out["dev"])                     # (B, K)
    pen = TAU * torch.nn.functional.softplus((smax - DELTA_TARGET) / TAU)
    return pen.sum(-1).mean(), smax


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("name")
    ap.add_argument("--model", default="gnn")
    ap.add_argument("--label", default="tsc")
    ap.add_argument("--lam_pf", type=float, default=0.0)
    ap.add_argument("--lam_stab", type=float, default=0.0)
    ap.add_argument("--epochs", type=int, default=300)
    ap.add_argument("--stab_epochs", type=int, default=30)
    ap.add_argument("--surrogate", default="node")   # node | classical
    ap.add_argument("--tag", required=True)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    torch.manual_seed(a.seed)
    np.random.seed(a.seed)
    B = Bundle(a.name)
    gt = B.gt
    tr, va = B.XY(B.train, a.label), B.XY(B.val, a.label)
    # standardisation scales for the supervised loss
    sc = {"Vm": torch.tensor(0.01), "Va": torch.tensor(0.05),
          "Pg": 0.1 * (gt.Pmax - gt.Pmin).clamp(min=0.1)}
    net = (BusGNN(gt) if a.model == "gnn" else MLPPredictor(gt))
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-5)
    total = a.epochs + (a.stab_epochs if a.lam_stab > 0 else 0)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=2e-3, total_steps=total * (1 + len(B.train) // 64) + 10)
    ntr = len(B.train)

    def sup_loss(out, y):
        Vm, Va, Pg = out
        return sum(((p - y[k]) / sc[k]).pow(2).mean() for p, k in [(Vm, "Vm"), (Va, "Va"), (Pg, "Pg")])

    def pf_loss(out, y):
        dP, dQ = gt.kcl(*out, y["Pd"], y["Qd"])
        return dP.pow(2).mean() + dQ.pow(2).mean()

    sur, dyn = None, None
    if a.lam_stab > 0:
        sur = Surrogate(B.md, learned=(a.surrogate == "node"))
        if a.surrogate == "node":
            sur.load_state_dict(torch.load(f"{OUT}/{a.name}_surrogate.pt"))
        for p in sur.parameters():
            p.requires_grad_(False)
        dyn = B.dyn(B.train, a.label)
    log = []
    t0 = time.time()
    best, best_state = np.inf, None
    for ep in range(total):
        net.train()
        stab_phase = a.lam_stab > 0 and ep >= a.epochs
        perm = torch.randperm(ntr)
        bs = 64
        agg = np.zeros(3)
        for s in range(0, ntr, bs):
            idx = perm[s:s + bs]
            y = sel(tr, idx)
            out = net(y["Pd"], y["Qd"])
            ls = sup_loss(out, y)
            lp = pf_loss(out, y) if a.lam_pf > 0 else torch.zeros(())
            loss = ls + a.lam_pf * lp
            lst = torch.zeros(())
            if stab_phase:
                sub = idx[:8]
                lst, _ = stability_penalty(sur, out[2][:8], sel(dyn, sub), B.g.slack_gen, B.c["tc"], dt=B.c["sdt"])
                loss = loss + a.lam_stab * lst
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
            opt.step()
            sched.step()
            agg += np.array([ls.item(), lp.item(), lst.item()]) * len(idx)
        net.eval()
        with torch.no_grad():
            ov = net(va["Pd"], va["Qd"])
            vs = sup_loss(ov, va).item()
            vp = pf_loss(ov, va).item()
        log.append(dict(ep=ep, sup=agg[0] / ntr, pf=agg[1] / ntr, stab=agg[2] / ntr, val_sup=vs, val_pf=vp))
        # model selection on validation supervised+physics loss (stability phase: keep last)
        crit = vs + a.lam_pf * vp
        if stab_phase or crit < best:
            best, best_state = crit, {k: v.clone() for k, v in net.state_dict().items()}
        if ep % 25 == 0 or ep == total - 1:
            print(f"[{a.tag}] ep {ep} sup {agg[0]/ntr:.4f} pf {agg[1]/ntr:.2e} stab {agg[2]/ntr:.4f} | val sup {vs:.4f} pf {vp:.2e} {time.time()-t0:.0f}s", flush=True)
    net.load_state_dict(best_state)
    torch.save(dict(state=net.state_dict(), args=vars(a)), f"{OUT}/{a.name}_{a.tag}.pt")
    json.dump(dict(args=vars(a), log=log, train_time_s=time.time() - t0),
              open(f"{OUT}/{a.name}_{a.tag}_train.json", "w"))


if __name__ == "__main__":
    main()
