"""Figure replacing the original voltage-scatter / residual figures: for every test scenario,
(a) predicted vs AC-OPF-reference bus voltage magnitudes (TSC-OPF labels), and
(b) per-bus KCL mismatch of the raw network output vs after AC feasibility restoration
(log scale, one test scenario), for the selected configuration on both systems."""
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from prep import Bundle
from pipeline import load_predictor
from config import OUT

plt.rcParams.update({"font.size": 8.5, "axes.grid": True, "grid.alpha": 0.3, "figure.dpi": 150})
TAG = "mlp_lam0.3"


def main():
    fig, axs = plt.subplots(2, 2, figsize=(7.4, 5.4))
    for col, name in enumerate(["case39", "case118"]):
        B = Bundle(name)
        g = B.g
        net = load_predictor(B, TAG)
        X = B.XY(B.test, "tsc")
        with torch.no_grad():
            Vm, Va, Pg = net(X["Pd"], X["Qd"])
            dP, dQ = B.gt.kcl(Vm, Va, Pg, X["Pd"], X["Qd"])
        ax = axs[0, col]
        ax.scatter(X["Vm"].numpy().ravel(), Vm.numpy().ravel(), s=3, alpha=0.25, color="#2a78d6", edgecolor="none")
        lo, hi = g.Vmin.min() - 0.005, g.Vmax.max() + 0.005
        ax.plot([lo, hi], [lo, hi], color="#555555", lw=1)
        ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
        mae = (Vm - X["Vm"]).abs().mean().item()
        ax.set_xlabel("TSC-OPF reference |V| (p.u.)")
        ax.set_ylabel("Predicted |V| (p.u.)")
        ax.set_title(f"({'ab'[col]}) {name.replace('case', 'IEEE ')}-bus, {len(B.test)} test scenarios, MAE {mae:.4f} p.u.", fontsize=8)
        # per-bus residual for the first test scenario: raw vs restored
        r = B.test[0]
        raw = np.zeros(g.nb)
        raw[:] = np.abs(dP[0].numpy())
        nongen = np.where(~B.gt.isgen.numpy())[0]
        raw[nongen] = np.maximum(raw[nongen], np.abs(dQ[0].numpy()))
        st = g.restore(Pg[0].numpy(), Vm[0].numpy()[g.gbus], r["Pd"], r["Qd"])
        res = g.kcl_residual(st, r["Pd"], r["Qd"])
        ax = axs[1, col]
        idx = np.arange(1, g.nb + 1)
        ax.semilogy(idx, np.maximum(raw, 1e-16), "o", ms=2.5, color="#eb6834", label="raw network output")
        ax.semilogy(idx, np.maximum(res, 1e-16), "o", ms=2.5, color="#2a78d6", label="after restoration (0 plotted at 1e-16)")
        ax.axhline(1e-8, color="#333333", ls="--", lw=1, label="Newton PF tolerance 1e-8")
        ax.set_xlabel("Bus index")
        ax.set_ylabel("|ΔS| nodal mismatch (p.u.)")
        ax.set_title(f"({'cd'[col]}) {name.replace('case', 'IEEE ')}-bus, one test scenario "
                     f"({st['iters']} restoration iterations)", fontsize=8)
        ax.legend(fontsize=6.5, loc="center right")
    fig.tight_layout()
    fig.savefig(f"{OUT}/figures/fig_voltage_residuals.png")


if __name__ == "__main__":
    main()
