"""Headline tables for the paper: operational protocol with certificate + fallback.

For a screened method, a dispatch is *accepted* if the AC restoration converged and the
surrogate certificate holds; otherwise the scenario falls back to the conventional
TSC-OPF solver. Latencies use the single-thread benchmark (timing.py) when available.
"""
import json
import os
import pickle
import numpy as np
from config import OUT

SCREENED = ["PI-GNN + correction", "Proposed (classical surrogate)", "Proposed", "Proposed (MLP backbone)",
            "Proposed (selected backbone)", "MLP-TSC + certificate"]
HEAD = ["AC-OPF (PIPS)", "TSC-OPF (iterative)", "MLP-OPF (DeepOPF-style)", "GNN-OPF", "MLP-TSC", "PI-GNN-TSC",
        "PI-GNN + stab. loss", "PI-MLP + stab. loss"] + SCREENED


def by_idx(rows):
    return {r["idx"]: r for r in rows}


def clean_latency(name):
    p = f"{OUT}/{name}_timing.json"
    return {k: v["mean"] for k, v in json.load(open(p))["summary"].items()} if os.path.exists(p) else {}


def row_metrics(R, m, s, lat, fallback):
    rows = R[(m, s)]
    opf, tsc = by_idx(R[("AC-OPF (PIPS)", s)]), by_idx(R[("TSC-OPF (iterative)", s)])
    t_tsc = lat.get("TSC-OPF (iterative)", np.mean([r["time"]["total"] for r in tsc.values() if r["feasible"]]))
    t_m = lat.get(m, np.mean([r["time"]["total"] for r in rows if r["feasible"]]))
    out = []
    for r in rows:
        ref = tsc[r["idx"]]
        acc = r["feasible"] and (not fallback or bool(r.get("certified")))
        if acc:
            out.append(dict(ok=True, secure=r["secure"], cost=r["cost"], fb=False, ref=ref, opf=opf[r["idx"]]))
        elif fallback:
            out.append(dict(ok=ref["feasible"], secure=ref.get("secure", False), cost=ref.get("cost", np.nan), fb=True,
                            ref=ref, opf=opf[r["idx"]]))
        else:
            out.append(dict(ok=False, secure=False, cost=np.nan, fb=False, ref=ref, opf=opf[r["idx"]]))
    n = len(out)
    ok = [o for o in out if o["ok"]]
    gap_t = [100 * (o["cost"] / o["ref"]["cost"] - 1) for o in ok if o["ref"]["feasible"] and o["ref"].get("secure")]
    gap_o = [100 * (o["cost"] / o["opf"]["cost"] - 1) for o in ok]
    fb = np.mean([o["fb"] for o in out])
    return dict(n=n, solved=100 * len(ok) / n, secure=100 * np.mean([o["ok"] and o["secure"] for o in out]),
                fallback=100 * fb, gap_opf=np.mean(gap_o), gap_tsc=np.mean(gap_t) if gap_t else np.nan,
                latency=t_m + (fb * t_tsc if fallback else 0.0), t_tsc=t_tsc)


def f(v, d=2):
    return "–" if v is None or (isinstance(v, float) and np.isnan(v)) else f"{v:.{d}f}"


def main():
    md = []
    for name in ["case39", "case118"]:
        R = pickle.load(open(f"{OUT}/{name}_results.pkl", "rb"))
        lat = clean_latency(name)
        sel = json.load(open(f"{OUT}/{name}_selection.json")).get("_selected") if os.path.exists(f"{OUT}/{name}_selection.json") else None
        for s in ["test", "ood"]:
            md.append(f"### {name} – {s} (n={len(R[('AC-OPF (PIPS)', s)])})\n")
            md.append("| Method | Solved % | Secure % | Fallback % | Gap vs AC-OPF % | Gap vs TSC-OPF % | Mean latency (s) | Speed-up vs TSC-OPF |")
            md.append("|---|---|---|---|---|---|---|---|")
            for m in HEAD:
                if (m, s) not in R:
                    continue
                for fb in ([False, True] if m in SCREENED else [False]):
                    M = row_metrics(R, m, s, lat, fb)
                    lab = m + (" + fallback" if fb else "") + (f" [{sel}]" if m == "Proposed (selected backbone)" and sel else "")
                    md.append(f"| {lab} | {f(M['solved'],1)} | {f(M['secure'],1)} | {f(M['fallback'],1) if fb else '–'} | "
                              f"{f(M['gap_opf'])} | {f(M['gap_tsc'])} | {f(M['latency'],3)} | {f(M['t_tsc']/M['latency'],1)}× |")
            md.append("")
        md.append(f"Latency source: {'single-thread benchmark (timing.py) for ' + ', '.join(lat) if lat else 'evaluation run'}; "
                  "other methods use evaluation-run wall time (2 jobs sharing 2 cores).\n")
    open(f"{OUT}/HEADLINE.md", "w").write("\n".join(md))
    print("\n".join(md))


if __name__ == "__main__":
    main()
