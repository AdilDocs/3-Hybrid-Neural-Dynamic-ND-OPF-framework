"""Seed robustness: retrain the main learned models with extra random seeds and evaluate
them on the test set exactly as in evaluate.py (high-fidelity re-simulation; conformal
margin calibrated on the validation set for certified pipelines). Seed 0 = main results.
usage: python seeds.py case39 1 2
"""
import os
import sys
import pickle
import subprocess
from prep import Bundle
from pipeline import Pipeline, load_predictor, load_surrogate
from evaluate import run_learned, calibrate
from config import OUT

MODELS = {  # base tag: (train args, certified pipeline?)
    "mlp_opf": ("--model mlp --label opf", False),
    "mlp_tsc": ("--model mlp --label tsc", True),
    "mlp_lam0.3": ("--model mlp --label tsc --lam_pf 0.1 --lam_stab 0.3", True),
    "mlp_full": ("--model mlp --label tsc --lam_pf 0.1 --lam_stab 1.0", True),
}


def main(name, seeds):
    path = f"{OUT}/{name}_seeds.pkl"
    res = pickle.load(open(path, "rb")) if os.path.exists(path) else {}
    B = None
    for s in seeds:
        for base, (args, cert) in MODELS.items():
            tag = f"{base}_s{s}"
            if (base, s) in res:
                continue
            if not os.path.exists(f"{OUT}/{name}_{tag}.pt"):
                cmd = f"python3 train_predictor.py {name} --epochs 100 --stab_epochs 12 {args} --seed {s} --tag {tag}"
                subprocess.run(cmd, shell=True, check=True)
            B = B or Bundle(name)
            net = load_predictor(B, tag)
            if cert:
                sur = load_surrogate(B, "node")
                q, _ = calibrate(B, net, sur)
                pipe = Pipeline(B, net, sur, correct=True, qhat=q)
            else:
                q, pipe = None, Pipeline(B, net, None, correct=False)
            res[(base, s)] = dict(qhat=q, rows=run_learned(B, B.test, pipe, tag))
            pickle.dump(res, open(path, "wb"))
            print(name, tag, "done", flush=True)


if __name__ == "__main__":
    main(sys.argv[1], [int(x) for x in sys.argv[2:]])
