"""Validation-set model selection (no test data used).
For every candidate first-stage predictor, run predictor + AC restoration on the
validation scenarios, re-simulate with the high-fidelity model and record
secure rate and cost gap vs. TSC-OPF. Selection rule (fixed in advance):
highest validation secure rate; candidates within 1 percentage point of the best
are tie-broken by the lowest mean cost gap.
usage: python select_backbone.py case39 tag1 tag2 ...
"""
import sys
import json
import time
import numpy as np
from prep import Bundle
from pipeline import Pipeline, load_predictor
from evaluate import run_learned
from config import OUT


def main(name, tags):
    B = Bundle(name)
    path = f"{OUT}/{name}_selection.json"
    try:
        res = json.load(open(path))
    except FileNotFoundError:
        res = {}
    tsc = {r["idx"]: r["tsc_cost"] for r in B.val}
    for tag in tags:
        if tag in res:
            continue
        t0 = time.time()
        rows = run_learned(B, B.val, Pipeline(B, load_predictor(B, tag), None, correct=False), tag)
        feas = [r for r in rows if r["feasible"]]
        res[tag] = dict(n=len(rows), feasible=100 * len(feas) / len(rows),
                        secure=100 * np.mean([r["feasible"] and r["secure"] for r in rows]),
                        gap_tsc=float(np.mean([100 * (r["cost"] / tsc[r["idx"]] - 1) for r in feas])))
        print(name, tag, res[tag], f"{time.time() - t0:.0f}s", flush=True)
        json.dump(res, open(path, "w"), indent=1)
    best = max(v["secure"] for v in res.values())
    cand = {k: v for k, v in res.items() if v["secure"] >= best - 1.0}
    sel = min(cand, key=lambda k: cand[k]["gap_tsc"])
    res["_selected"] = sel
    json.dump(res, open(path, "w"), indent=1)
    print("selected", sel)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2:])
