"""Turn raw scenario records into train/val/test tensors."""
import pickle
import numpy as np
import torch
from config import CFG, ROOT, DATA_SUFFIX
from grid import load_grid
from dynamics import MachineData, Contingency
from models import GridTensors, dyn_tensors, stack_dyn


class Bundle:
    def __init__(self, name, seed=0, file=None):
        self.name = name
        self.g = load_grid(name)
        self.md = MachineData(self.g)
        self.c = CFG[name]
        self.conts = [Contingency(self.g, b, l, self.c["tc"]) for b, l in self.c["conts"]]
        self.gt = GridTensors(self.g)
        recs = pickle.load(open(file or f"{ROOT}/data/{name}{DATA_SUFFIX}.pkl", "rb"))
        self.recs = recs
        ok_in = [r for r in recs if r["ok"] and r["split"] == "in" and "tsc" in r and r["tsc_secure"]]
        traj_ids = {r["idx"] for r in ok_in if "traj" in r}
        rest = [r for r in ok_in if r["idx"] not in traj_ids]
        rng = np.random.default_rng(seed)
        rng.shuffle(rest)
        n_test = n_val = int(round(0.125 * len(ok_in)))
        self.test = rest[:n_test]
        self.val = rest[n_test:n_test + n_val]
        self.train = [r for r in ok_in if r["idx"] in traj_ids] + rest[n_test + n_val:]
        self.ood = [r for r in recs if r["ok"] and r["split"] == "ood"]
        self.stats = dict(
            n_total=len(recs), n_opf_ok=sum(r["ok"] for r in recs),
            n_in_ok=len(ok_in), n_train=len(self.train), n_val=len(self.val), n_test=len(self.test),
            n_ood=len(self.ood),
            n_in_tsc_insecure=sum(1 for r in recs if r["ok"] and r["split"] == "in" and "tsc" in r and not r["tsc_secure"]),
        )

    def XY(self, recs, label="tsc"):
        t = lambda a: torch.tensor(np.stack(a))
        Pd = t([r["Pd"] for r in recs]); Qd = t([r["Qd"] for r in recs])
        lab = [r[label] for r in recs]
        V = np.stack([l["V"] for l in lab])
        return dict(Pd=Pd, Qd=Qd, Vm=torch.tensor(np.abs(V)), Va=torch.tensor(np.angle(V)),
                    Pg=t([l["Pg"] for l in lab]))

    def dyn(self, recs, label="tsc"):
        items = [dyn_tensors(self.g, self.md, r[label], r["Pd"], r["Qd"], self.conts) for r in recs]
        return stack_dyn(items)

    def traj_set(self):
        """Surrogate training data: (dyn tensors, true trajectories)."""
        items, trajs = [], []
        for r in self.train:
            if "traj" not in r:
                continue
            for st, tr in zip(r["traj_states"], r["traj"]):
                items.append(dyn_tensors(self.g, self.md, st, r["Pd"], r["Qd"], self.conts))
                trajs.append(tr["traj"])     # (T, K, 4, ng) float32, dt=0.01
        return stack_dyn(items), torch.tensor(np.stack(trajs)).double()
