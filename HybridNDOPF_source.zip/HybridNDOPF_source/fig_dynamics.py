"""Figure: post-fault rotor angles (COI deviation coordinates) for one test scenario,
AC-OPF dispatch vs. proposed dispatch, high-fidelity truth vs neural-ODE prediction."""
import sys
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from prep import Bundle
from pipeline import Pipeline, load_predictor, load_surrogate
from dynamics import simulate
from models import dyn_tensors, stack_dyn
from tscopf import DELTA_LIM
from config import OUT

plt.rcParams.update({"font.size": 8.5, "axes.grid": True, "grid.alpha": 0.3, "figure.dpi": 150})


def main(name="case39", which=0):
    B = Bundle(name)
    r = B.test[which]
    sur = load_surrogate(B, "node")
    pipe = Pipeline(B, load_predictor(B, "mlp_lam0.3"), sur, correct=True)
    st, info = pipe(r["Pd"], r["Qd"])
    opf = B.g._state(r["opf"]["V"], r["Pd"], r["Qd"])
    k = int(np.argmax(r["opf_maxdev"]))       # most severe contingency for the OPF dispatch
    conts = [B.conts[k]]
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 2.9), sharey=False)
    for ax, (lab, s) in zip(axs, [("(a) AC-OPF dispatch", opf), ("(b) Proposed dispatch", st)]):
        tr = simulate(B.g, B.md, s, r["Pd"], r["Qd"], conts, model="flux", T=3.0, record=True)
        dev = tr["traj"][:, 0, 0] - tr["coi"][:, 0, None]
        ax.plot(tr["t"], np.degrees(dev), color="#2a78d6", lw=1.0, alpha=0.85)
        if "Proposed" in lab:
            d = stack_dyn([dyn_tensors(B.g, B.md, s, r["Pd"], r["Qd"], conts)])
            with torch.no_grad():
                o = sur.simulate(d["delta0"], d["e0"], d["Pm"], d["Ypre"], d["Yf"], d["Yp"], B.c["tc"],
                                 T=3.0, dt=B.c["sdt"])
            tt = B.c["sdt"] * (1 + np.arange(o["dev"].shape[0]))
            ax.plot(tt, np.degrees(o["dev"][:, 0, 0].numpy()), color="#eb6834", lw=1.0, ls="--")
            ax.plot([], [], color="#2a78d6", label="high-fidelity simulator")
            ax.plot([], [], color="#eb6834", ls="--", label="neural-ODE surrogate")
            ax.legend(fontsize=7, loc="lower right")
        for y in (np.degrees(DELTA_LIM), -np.degrees(DELTA_LIM)):
            ax.axhline(y, color="#e34948", lw=1, ls=":")
        ax.axvspan(0, B.c["tc"], color="#cccccc", alpha=0.5, lw=0)
        ax.set_xlabel("Time after fault (s)")
        ax.set_ylabel("δ_g − δ_COI (deg)")
        ax.set_title(f"{lab}: max {np.degrees(np.abs(dev).max()):.0f}°", fontsize=8.5)
        if np.abs(dev).max() > np.pi:
            ax.set_ylim(-360, 720)
    i2e = B.g.ppc["order"]["bus"]["i2e"]
    c = B.conts[k]
    desc = (f"3-phase fault at bus {int(i2e[c.bus])}, line {int(i2e[B.g.f[c.line]])}-{int(i2e[B.g.t[c.line]])} "
            f"tripped at {c.tc:.2f} s")
    fig.suptitle(f"{name.replace('case', 'IEEE ')}-bus test scenario: {desc} (shaded: fault on; dotted: ±{np.degrees(DELTA_LIM):.0f}° limit)",
                 fontsize=8)
    fig.tight_layout()
    fig.savefig(f"{OUT}/figures/fig_dynamics_{name}.png")
    print("cost gap vs AC-OPF %.2f%%" % (100 * (B.g.cost(st["Pg"]) / r["opf_cost"] - 1)), info["rounds"])


if __name__ == "__main__":
    main(*(sys.argv[1:2] or ["case39"]))
