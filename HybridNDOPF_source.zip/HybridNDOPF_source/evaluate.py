"""Evaluate all methods on the test and OOD sets with the high-fidelity simulator.
usage: python evaluate.py case39 [methods...]
"""
import os
import sys
import json
import time
import pickle
import numpy as np
from prep import Bundle
from pipeline import Pipeline, load_predictor, load_surrogate
from dynamics import simulate
from tscopf import DELTA_LIM
from config import ROOT, OUT

ALPHA = 0.05   # conformal mis-coverage level


def ground_truth(B, st, Pd, Qd):
    r = simulate(B.g, B.md, st, Pd, Qd, B.conts, model="flux", T=3.0)
    md = r["max_dev"]
    return dict(max_dev=md.tolist(), secure=bool(np.all(md <= DELTA_LIM)), stable=bool(np.all(md < np.pi)))


def ac_quality(B, st, Pd, Qd):
    g = B.g
    return dict(kcl=float(g.kcl_residual(st, Pd, Qd).max()), maxviol=float(g.max_violation(st)),
                cost=float(g.cost(st["Pg"])))


def calibrate(B, net, sur):
    """Split-conformal margin on the validation set (dispatches before correction)."""
    pipe = Pipeline(B, net, sur, correct=False)
    res = []
    for r in B.val:
        st, info = pipe(r["Pd"], r["Qd"])
        if not st["success"]:
            continue
        gt = simulate(B.g, B.md, st, r["Pd"], r["Qd"], B.conts, model="flux", T=3.0)["max_dev"]
        res.append(np.minimum(gt, 2 * np.pi) - np.minimum(info["pred_dev"], 2 * np.pi))
    res = np.concatenate(res)
    n = len(res)
    q = np.quantile(res, min(1.0, np.ceil((n + 1) * (1 - ALPHA)) / n), method="higher")
    return float(max(q, 0.0)), res


def run_learned(B, recs, pipe, label):
    out = []
    for r in recs:
        st, info = pipe(r["Pd"], r["Qd"])
        row = dict(idx=r["idx"], alpha=r["alpha"], feasible=bool(st["success"]), time=info["time"],
                   restore_iters=info["restore_iters"], raw_kcl=info["raw_kcl"], rounds=info["rounds"],
                   restore_hist=info["restore_hist"],
                   certified=info["certified"])
        row.update(ac_quality(B, st, r["Pd"], r["Qd"]))
        row.update(ground_truth(B, st, r["Pd"], r["Qd"]))
        if info["pred_dev"] is not None:
            row["pred_dev"] = np.asarray(info["pred_dev"]).tolist()
        out.append(row)
    return out


def run_reference(B, recs, which):
    out = []
    for r in recs:
        if which not in r:
            out.append(dict(idx=r["idx"], alpha=r["alpha"], feasible=False))
            continue
        st = B.g._state(r[which]["V"], r["Pd"], r["Qd"])
        md = np.asarray(r[f"{which}_maxdev"])
        row = dict(idx=r["idx"], alpha=r["alpha"], feasible=True,
                   time=dict(total=float(r[f"{which}_time"])), max_dev=md.tolist(),
                   secure=bool(np.all(md <= DELTA_LIM)), stable=bool(np.all(md < np.pi)))
        row.update(ac_quality(B, st, r["Pd"], r["Qd"]))
        if which == "opf":
            # stability-unaware OPF: the cost of also checking security would add one simulation
            row["time"]["with_check"] = float(r["opf_time"] + r["sim_time"])
        out.append(row)
    return out


METHODS = {
    # name: (predictor tag, surrogate kind or None, correction?)
    "MLP-OPF (DeepOPF-style)": ("mlp_opf", None, False),
    "GNN-OPF": ("gnn_opf", None, False),
    "MLP-TSC": ("mlp_tsc", None, False),
    "GNN-TSC": ("gnn_tsc", None, False),
    "PI-GNN-TSC": ("gnn_tsc_pf", None, False),
    "PI-GNN + stab. loss": ("gnn_full", None, False),
    "PI-GNN + correction": ("gnn_tsc_pf", "node", True),
    "Proposed (classical surrogate)": ("gnn_full_cl", "classical", True),
    "Proposed": ("gnn_full", "node", True),
    "PI-MLP-TSC": ("mlp_tsc_pf", None, False),
    "PI-MLP + stab. loss": ("mlp_full", None, False),
    "Proposed (MLP backbone)": ("mlp_full", "node", True),
    # backbone chosen on the validation set by select_backbone.py (same rule for both systems)
    "Proposed (selected backbone)": ("mlp_lam0.3", "node", True),
    # ablation: certificate + correction on the plain imitation model (lambda_stab = 0)
    "MLP-TSC + certificate": ("mlp_tsc", "node", True),
}


def main(name, only=None):
    B = Bundle(name)
    sets = {"test": B.test, "ood": B.ood}
    path = f"{OUT}/{name}_results{os.environ.get('RES_TAG', '')}.pkl"
    try:
        allres = pickle.load(open(path, "rb"))
    except FileNotFoundError:
        allres = {}
    allres["_stats"] = B.stats
    # references
    for sname, recs in sets.items():
        allres[("AC-OPF (PIPS)", sname)] = run_reference(B, recs, "opf")
        allres[("TSC-OPF (iterative)", sname)] = run_reference(B, recs, "tsc")
    qh = {}

    def qhat_for(tag, kind):
        if (tag, kind) not in qh:
            q, res = calibrate(B, load_predictor(B, tag), load_surrogate(B, kind))
            qh[(tag, kind)] = q
            allres[("_conformal", kind, tag)] = dict(qhat=q, residuals=res.tolist())
            print(name, "conformal qhat", tag, kind, round(q, 3), flush=True)
        return qh[(tag, kind)]

    for m, (tag, kind, corr) in METHODS.items():
        if only and m not in only:
            continue
        net = load_predictor(B, tag)
        sur = load_surrogate(B, kind) if kind else None
        pipe = Pipeline(B, net, sur, correct=corr, qhat=qhat_for(tag, kind) if kind else 0.0)
        for sname, recs in sets.items():
            t0 = time.time()
            allres[(m, sname)] = run_learned(B, recs, pipe, tag)
            print(name, m, sname, f"{time.time() - t0:.0f}s", flush=True)
        pickle.dump(allres, open(path, "wb"))
    pickle.dump(allres, open(path, "wb"))
    qp = f"{OUT}/{name}_qhat{os.environ.get('RES_TAG', '')}.json"
    old = json.load(open(qp)) if os.path.exists(qp) else {}
    old.update({tag: q for (tag, kind), q in qh.items() if kind == "node"})
    json.dump(old, open(qp, "w"))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2:] or None)
