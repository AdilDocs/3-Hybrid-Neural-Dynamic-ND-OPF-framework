"""Learning components (PyTorch, CPU):
  * BusGNN      : physics-informed GNN predicting the AC operating point
  * MLPPredictor: DeepOPF-style fully connected baseline
  * Surrogate   : physics-structured neural ODE of post-fault dynamics
                  (known swing + network physics, learned flux/excitation closure)
  * steady_state: differentiable implicit layer  P_e(δ) = P_m  (Newton, unrolled)
"""
import numpy as np
import torch
import torch.nn as nn

torch.set_default_dtype(torch.float64)
OMEGA_B = 2 * np.pi * 60.0


# --------------------------------------------------------------------------
# Feature construction shared by predictors
# --------------------------------------------------------------------------
class GridTensors:
    def __init__(self, g):
        self.g = g
        self.nb, self.ng = g.nb, g.ng
        Y = g.Ybus.toarray()
        self.G = torch.tensor(Y.real)
        self.B = torch.tensor(Y.imag)
        self.gbus = torch.tensor(g.gbus)
        self.Pmin = torch.tensor(g.Pmin)
        self.Pmax = torch.tensor(g.Pmax)
        self.Vmin = torch.tensor(g.Vmin)
        self.Vmax = torch.tensor(g.Vmax)
        self.ref = g.ref
        ei = np.concatenate([g.edges, g.edges[::-1]], 1)
        self.src = torch.tensor(ei[0])
        self.dst = torch.tensor(ei[1])
        yij = -Y[ei[0], ei[1]]
        self.efeat = torch.tensor(np.stack([yij.real, yij.imag], 1))
        self.efeat = self.efeat / self.efeat.abs().max(0).values
        isgen = np.zeros(g.nb); isgen[g.gbus] = 1
        pmax = np.zeros(g.nb); pmax[g.gbus] = g.Pmax
        pmin = np.zeros(g.nb); pmin[g.gbus] = g.Pmin
        c1 = np.zeros(g.nb); c1[g.gbus] = g.c1 / max(g.c1.max(), 1e-9)
        isref = np.zeros(g.nb); isref[g.ref] = 1
        self.static = torch.tensor(np.stack([isgen, pmax, pmin, c1, isref, g.Vmin, g.Vmax], 1))
        self.isgen = torch.tensor(isgen, dtype=torch.bool)

    def node_features(self, Pd, Qd):
        B = Pd.shape[0]
        st = self.static.unsqueeze(0).expand(B, -1, -1)
        return torch.cat([Pd.unsqueeze(-1), Qd.unsqueeze(-1), st], -1)

    def kcl(self, Vm, Va, Pg, Pd, Qd):
        """Nodal mismatch with free reactive output at generator buses."""
        Vr, Vi = Vm * torch.cos(Va), Vm * torch.sin(Va)
        Ir = Vr @ self.G.T - Vi @ self.B.T
        Ii = Vr @ self.B.T + Vi @ self.G.T
        P = Vr * Ir + Vi * Ii
        Q = Vi * Ir - Vr * Ii
        Pinj = -Pd.clone()
        Pinj[:, self.gbus] = Pinj[:, self.gbus] + Pg
        dP = P - Pinj
        dQ = (Q + Qd)[:, ~self.isgen]
        return dP, dQ


class MPLayer(nn.Module):
    def __init__(self, h):
        super().__init__()
        self.msg = nn.Sequential(nn.Linear(2 * h + 2, h), nn.SiLU(), nn.Linear(h, h))
        self.upd = nn.Sequential(nn.Linear(2 * h, h), nn.SiLU(), nn.Linear(h, h))
        self.norm = nn.LayerNorm(h)

    def forward(self, x, gt):
        B, N, H = x.shape
        xs, xd = x[:, gt.src], x[:, gt.dst]
        e = gt.efeat.unsqueeze(0).expand(B, -1, -1)
        m = self.msg(torch.cat([xs, xd, e], -1))
        agg = torch.zeros_like(x).index_add_(1, gt.dst, m)
        return self.norm(x + self.upd(torch.cat([x, agg], -1)))


class Heads(nn.Module):
    """Maps a per-bus embedding to (Vm, Va, Pg) with hard box bounds."""

    def __init__(self, gt, h):
        super().__init__()
        self.gt = gt
        self.vm = nn.Linear(h, 1)
        self.va = nn.Linear(h, 1)
        self.pg = nn.Linear(h, 1)

    def forward(self, z):
        gt = self.gt
        Vm = gt.Vmin + (gt.Vmax - gt.Vmin) * torch.sigmoid(self.vm(z).squeeze(-1))
        Va = 0.5 * torch.tanh(self.va(z).squeeze(-1)) * np.pi
        Va = Va - Va[:, gt.ref:gt.ref + 1]
        zg = z[:, gt.gbus]
        Pg = gt.Pmin + (gt.Pmax - gt.Pmin) * torch.sigmoid(self.pg(zg).squeeze(-1))
        return Vm, Va, Pg


class BusGNN(nn.Module):
    def __init__(self, gt, h=64, layers=4):
        super().__init__()
        self.gt = gt
        self.inp = nn.Sequential(nn.Linear(9, h), nn.SiLU(), nn.Linear(h, h))
        self.layers = nn.ModuleList([MPLayer(h) for _ in range(layers)])
        self.glob = nn.Sequential(nn.Linear(h, h), nn.SiLU())
        self.heads = Heads(gt, 2 * h)

    def forward(self, Pd, Qd):
        x = self.inp(self.gt.node_features(Pd, Qd))
        for L in self.layers:
            x = L(x, self.gt)
        g = self.glob(x.mean(1, keepdim=True)).expand(-1, x.shape[1], -1)
        return self.heads(torch.cat([x, g], -1))


class MLPPredictor(nn.Module):
    """DeepOPF-style baseline: load vector -> (Vm, Va, Pg)."""

    def __init__(self, gt, h=512):
        super().__init__()
        self.gt = gt
        nb, ng = gt.nb, gt.ng
        self.net = nn.Sequential(nn.Linear(2 * nb, h), nn.SiLU(), nn.Linear(h, h), nn.SiLU(),
                                 nn.Linear(h, h), nn.SiLU(), nn.Linear(h, 2 * nb + ng))

    def forward(self, Pd, Qd):
        gt = self.gt
        o = self.net(torch.cat([Pd, Qd], -1))
        nb = gt.nb
        Vm = gt.Vmin + (gt.Vmax - gt.Vmin) * torch.sigmoid(o[:, :nb])
        Va = 0.5 * torch.tanh(o[:, nb:2 * nb]) * np.pi
        Va = Va - Va[:, gt.ref:gt.ref + 1]
        Pg = gt.Pmin + (gt.Pmax - gt.Pmin) * torch.sigmoid(o[:, 2 * nb:])
        return Vm, Va, Pg


# --------------------------------------------------------------------------
# Dynamics: implicit steady-state layer + physics-structured neural ODE
# --------------------------------------------------------------------------
def cmatvec(Yr, Yi, Er, Ei):
    """Batched complex mat-vec with real tensors. Y: (..., n, n), E: (..., n)."""
    Ir = torch.einsum("...ij,...j->...i", Yr, Er) - torch.einsum("...ij,...j->...i", Yi, Ei)
    Ii = torch.einsum("...ij,...j->...i", Yr, Ei) + torch.einsum("...ij,...j->...i", Yi, Er)
    return Ir, Ii


def block(Yr, Yi):
    """Real 2n x 2n representation [[Yr, -Yi], [Yi, Yr]] of a complex matrix."""
    return torch.cat([torch.cat([Yr, -Yi], -1), torch.cat([Yi, Yr], -1)], -2)


def electrical_power(delta, e, Yr, Yi=None):
    """Yr may be a precomputed real block matrix (Yi=None)."""
    Er, Ei = e * torch.cos(delta), e * torch.sin(delta)
    if Yi is None:
        n = Er.shape[-1]
        I = (Yr @ torch.cat([Er, Ei], -1).unsqueeze(-1)).squeeze(-1)
        Ir, Ii = I[..., :n], I[..., n:]
    else:
        Ir, Ii = cmatvec(Yr, Yi, Er, Ei)
    return Er * Ir + Ei * Ii, (Er, Ei, Ir, Ii)


def steady_state(Pm, e, Yr, Yi, delta0, slack, iters=6):
    """Implicit layer: find δ with P_e(δ) = P_m for all non-slack machines (δ_slack fixed).
    Unrolled Newton steps keep the map Pm -> δ differentiable."""
    d = delta0.clone()
    n = d.shape[-1]
    keep = [i for i in range(n) if i != slack]
    for _ in range(iters):
        Pe, (Er, Ei, Ir, Ii) = electrical_power(d, e, Yr, Yi)
        F = (Pe - Pm)[:, keep]
        # Jacobian dPe_i/dδ_j
        # P_i = Re(E_i conj(sum_j Y_ij E_j)); dE_j/dδ_j = j E_j
        Er_, Ei_ = Er.unsqueeze(-1), Ei.unsqueeze(-1)
        # off-diagonal: Re(E_i conj(Y_ij j E_j))
        YEr = Yr * Er.unsqueeze(-2) - Yi * Ei.unsqueeze(-2)   # Re(Y_ij E_j)
        YEi = Yr * Ei.unsqueeze(-2) + Yi * Er.unsqueeze(-2)   # Im(Y_ij E_j)
        # j*Y_ij*E_j = -Im + j Re ; Re(E_i * conj(-YEi + j YEr)) = Er*(-YEi) + Ei*(YEr)
        J = -Er_ * YEi + Ei_ * YEr
        # diagonal adds Re(jE_i conj(I_i)) = -Ei*Ir + Er*Ii
        diag = -Ei * Ir + Er * Ii
        J = J + torch.diag_embed(diag)
        Jk = J[:, keep][:, :, keep]
        step = torch.linalg.solve(Jk, F.unsqueeze(-1)).squeeze(-1)
        d = d.clone()
        d[:, keep] = d[:, keep] - step
    return d


class Surrogate(nn.Module):
    """Reduced-order neural ODE per machine i:
        dδ/dt  = ω_b Δω
        dΔω/dt = (P_m − P_e(δ, e; Y(t)) − D Δω) / M            (known physics)
        de/dt, dz/dt = f_θ(e−e0, z, |V_t|−|V_t0|, I_d−I_d0, P_e−P_m, machine params)
    e is the internal-EMF magnitude, z a latent excitation state. With f_θ ≡ 0 the
    model reduces exactly to the classical model."""

    def __init__(self, md, hidden=64, learned=True):
        super().__init__()
        self.learned = learned
        self.M = torch.tensor(md.M)
        self.D = torch.tensor(md.D)
        self.xdp = torch.tensor(md.xdp)
        par = np.stack([np.log(md.H), np.log(md.xdp), np.log(md.xd), np.log(md.Tdo)], 1)
        self.par = torch.tensor((par - par.mean(0)) / (par.std(0) + 1e-9))
        self.f = nn.Sequential(nn.Linear(9, hidden), nn.Tanh(), nn.Linear(hidden, hidden), nn.Tanh(),
                               nn.Linear(hidden, 2))
        nn.init.zeros_(self.f[-1].weight)
        nn.init.zeros_(self.f[-1].bias)

    def rhs(self, x, Pm, Yb, ref):
        d, w, e, z = x.unbind(-2)
        Pe, (Er, Ei, Ir, Ii) = electrical_power(d, e, Yb)
        dd = OMEGA_B * w
        dw = (Pm - Pe - self.D * w) / self.M
        if not self.learned:
            return torch.stack([dd, dw, torch.zeros_like(e), torch.zeros_like(z)], -2)
        # terminal voltage and d-axis current
        Vr = Er + self.xdp * Ii
        Vi = Ei - self.xdp * Ir
        Vt = torch.sqrt(Vr ** 2 + Vi ** 2)
        Id = Ir * torch.sin(d) - Ii * torch.cos(d)
        feat = torch.stack([e - ref["e0"], z, Vt - ref["Vt0"], Id - ref["Id0"], Pe - Pm], -1)
        feat = torch.cat([feat, self.par.expand(*feat.shape[:-1], 4)], -1)
        out = self.f(feat)
        return torch.stack([dd, dw, out[..., 0], out[..., 1]], -2)

    def reference(self, delta0, e0, Pm, Ypre_r, Ypre_i):
        Pe, (Er, Ei, Ir, Ii) = electrical_power(delta0, e0, Ypre_r, Ypre_i)
        Vr = Er + self.xdp * Ii
        Vi = Ei - self.xdp * Ir
        return dict(e0=e0, Vt0=torch.sqrt(Vr ** 2 + Vi ** 2), Id0=Ir * torch.sin(delta0) - Ii * torch.cos(delta0))

    def simulate(self, delta0, e0, Pm, Ypre, Yf, Yp, tc, T=2.0, dt=0.01, record=False):
        """delta0,e0,Pm: (B, ng). Ypre: (B,ng,ng) complex as (r,i) tuple; Yf, Yp: (B,K,ng,ng).
        Returns max COI deviation per (B,K) and optionally the trajectory."""
        B, K = Yf[0].shape[:2]
        ng = delta0.shape[-1]
        ref = self.reference(delta0, e0, Pm, *Ypre)
        ref = {k: v.unsqueeze(1) for k, v in ref.items()}
        x = torch.stack([delta0, torch.zeros_like(delta0), e0, torch.zeros_like(e0)], -2)
        x = x.unsqueeze(1).expand(B, K, 4, ng).clone()
        Pm_ = Pm.unsqueeze(1)
        Mt = self.M.sum()
        nsteps = int(round(T / dt))
        ntc = int(round(tc / dt))
        devs, traj = [], []
        Ybf, Ybp = block(*Yf), block(*Yp)
        for n in range(nsteps):
            Yb = Ybf if n < ntc else Ybp
            f = lambda s: self.rhs(s, Pm_, Yb, ref)
            k1 = f(x); k2 = f(x + 0.5 * dt * k1); k3 = f(x + 0.5 * dt * k2); k4 = f(x + dt * k3)
            x = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
            coi = (x[:, :, 0] * self.M).sum(-1, keepdim=True) / Mt
            devs.append(x[:, :, 0] - coi)
            if record:
                traj.append(x)
        dev = torch.stack(devs, 0)                     # (T, B, K, ng)
        out = dict(dev=dev)
        if record:
            out["traj"] = torch.stack(traj, 0)
        return out


def soft_max_dev(dev, beta=20.0, cap=2 * np.pi):
    """Smooth max over time and machines of |δ − δ_COI| (clamped for gradient sanity)."""
    a = torch.clamp(dev.abs(), max=cap)
    T = a.shape[0]
    a = a.permute(1, 2, 0, 3).reshape(a.shape[1], a.shape[2], -1)
    return torch.logsumexp(beta * a, -1) / beta


def dyn_tensors(grid, md, st, Pd, Qd, conts):
    """Per-sample physics tensors for the surrogate (from an AC state)."""
    from dynamics import init_machines, reduced_matrices
    init = init_machines(grid, md, st, Pd, Qd)
    Ypre, Yf, Yp = reduced_matrices(grid, md, init, conts)
    return dict(delta0=init["delta"], e0=init["Eq"], Pm=init["Pm"],
                Ypre=Ypre, Yf=Yf, Yp=Yp)


def stack_dyn(items):
    t = lambda a: torch.tensor(np.stack(a))
    out = dict(delta0=t([d["delta0"] for d in items]), e0=t([d["e0"] for d in items]),
               Pm=t([d["Pm"] for d in items]))
    for k in ["Ypre", "Yf", "Yp"]:
        arr = np.stack([d[k] for d in items])
        out[k] = (torch.tensor(arr.real), torch.tensor(arr.imag))
    return out
