"""Validate the Lyapunov (transient-energy-function, PEBS) certificate against the
high-fidelity simulator on AC-OPF (insecure) and TSC-OPF (secure) test dispatches.
usage: python tef_eval.py case39 [n]"""
import sys, json, time
import numpy as np
from prep import Bundle
from certificate import tef_certificate
from tscopf import DELTA_LIM
from config import OUT


def main(name, n=None):
    B = Bundle(name)
    recs = B.test[:n] if n else B.test
    rows = []
    t0 = time.time()
    for r in recs:
        for which in ["opf", "tsc"]:
            st = B.g._state(r[which]["V"], r["Pd"], r["Qd"])
            cert, margin = tef_certificate(B.g, B.md, st, r["Pd"], r["Qd"], B.conts)
            md = np.asarray(r[f"{which}_maxdev"])
            rows.append(dict(idx=r["idx"], which=which, cert=cert.tolist(), margin=margin.tolist(),
                             stable=(md < np.pi).tolist(), secure=(md <= DELTA_LIM).tolist()))
    c = np.concatenate([x["cert"] for x in rows]); s = np.concatenate([x["stable"] for x in rows])
    out = dict(n_pairs=int(len(c)), certified=int(c.sum()), stable=int(s.sum()),
               precision_stable=float(s[c].mean()) if c.any() else None,      # P(stable | certified)
               recall_stable=float(c[s].mean()) if s.any() else None,         # P(certified | stable)
               false_cert=int((c & ~s).sum()), time_s=time.time() - t0)
    json.dump(dict(summary=out, rows=rows), open(f"{OUT}/{name}_tef.json", "w"))
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else None)
