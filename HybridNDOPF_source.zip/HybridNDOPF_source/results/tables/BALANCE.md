### IEEE 39-bus, test set (n=200), 95 % CIs (secure: Clopper-Pearson; others: bootstrap)

| Method | Secure % | Fallback % | Cost gap vs TSC-OPF % | Mean latency s | Expected-cost gap, π=1 % | π=10 % | π=100 % |
|---|---|---|---|---|---|---|---|
| AC-OPF (MIPS) | 0.0 [0.0, 1.8] | 0.0 | -0.85 [-0.91, -0.81] | 0.512 [0.494, 0.533] | 0.15 | 9.15 | 99.15 |
| TSC-OPF (iterative) | 100.0 [98.2, 100.0] | 0.0 | 0.00 [0.00, 0.00] | 2.309 [2.212, 2.418] | 0.00 | 0.00 | 0.00 |
| DeepOPF-style MLP | 0.0 [0.0, 1.8] | 0.0 | -0.75 [-0.81, -0.70] | 0.044 [0.033, 0.061] | 0.25 | 9.25 | 99.25 |
| MLP imitating TSC-OPF | 97.0 [93.6, 98.9] | 0.0 | 0.09 [0.03, 0.15] | 0.032 [0.029, 0.036] | 0.12 | 0.39 | 3.09 |
| Proposed, λ=0 + fallback | 100.0 [98.2, 100.0] | 1.0 | 0.14 [0.11, 0.18] | 0.140 [0.136, 0.145] | 0.14 | 0.14 | 0.14 |
| Proposed, λ=0.3 (selected) + fallback | 100.0 [98.2, 100.0] | 1.5 | 0.28 [0.25, 0.30] | 0.178 [0.164, 0.195] | 0.28 | 0.28 | 0.28 |
| Proposed, λ=1 + fallback | 100.0 [98.2, 100.0] | 0.5 | 0.35 [0.33, 0.37] | 0.143 [0.136, 0.151] | 0.35 | 0.35 | 0.35 |
| Proposed, GNN backbone, λ=1 + fallback | 100.0 [98.2, 100.0] | 1.0 | 0.54 [0.50, 0.59] | 0.431 [0.208, 0.726] | 0.54 | 0.54 | 0.54 |

### IEEE 118-bus, test set (n=147), 95 % CIs (secure: Clopper-Pearson; others: bootstrap)

| Method | Secure % | Fallback % | Cost gap vs TSC-OPF % | Mean latency s | Expected-cost gap, π=1 % | π=10 % | π=100 % |
|---|---|---|---|---|---|---|---|
| AC-OPF (MIPS) | 0.0 [0.0, 2.5] | 0.0 | -2.41 [-2.76, -2.12] | 0.749 [0.721, 0.781] | -1.41 | 7.59 | 97.59 |
| TSC-OPF (iterative) | 100.0 [97.5, 100.0] | 0.0 | 0.00 [0.00, 0.00] | 4.542 [4.354, 4.768] | 0.00 | 0.00 | 0.00 |
| DeepOPF-style MLP | 0.0 [0.0, 2.5] | 0.0 | -2.21 [-2.55, -1.89] | 0.276 [0.184, 0.382] | -1.21 | 7.79 | 97.79 |
| MLP imitating TSC-OPF | 97.3 [93.2, 99.3] | 0.0 | 0.19 [0.14, 0.24] | 0.130 [0.078, 0.193] | 0.22 | 0.46 | 2.91 |
| Proposed, λ=0 + fallback | 100.0 [97.5, 100.0] | 14.3 | 0.92 [0.75, 1.12] | 3.653 [2.557, 4.776] | 0.92 | 0.92 | 0.92 |
| Proposed, λ=0.3 (selected) + fallback | 100.0 [97.5, 100.0] | 6.1 | 1.56 [1.46, 1.66] | 1.125 [0.819, 1.549] | 1.56 | 1.56 | 1.56 |
| Proposed, λ=1 + fallback | 100.0 [97.5, 100.0] | 3.4 | 2.25 [2.15, 2.36] | 0.791 [0.647, 0.941] | 2.25 | 2.25 | 2.25 |
| Proposed, GNN backbone, λ=1 + fallback | 100.0 [97.5, 100.0] | 14.3 | 2.57 [2.35, 2.79] | 2.331 [1.481, 3.222] | 2.57 | 2.57 | 2.57 |

### IEEE 39-bus seed robustness (test set, mean ± std over seeds)

| Model | Seeds | Secure % | Fallback % | Cost gap vs TSC-OPF % |
|---|---|---|---|---|
| mlp_opf | 3 | 0.00 ± 0.00 | 0.00 ± 0.00 | -0.71 ± 0.03 |
| mlp_tsc + certificate + fallback | 3 | 100.00 ± 0.00 | 1.17 ± 0.29 | 0.17 ± 0.03 |
| mlp_lam0.3 + certificate + fallback | 3 | 100.00 ± 0.00 | 0.83 ± 0.58 | 0.28 ± 0.01 |
| mlp_full + certificate + fallback | 3 | 100.00 ± 0.00 | 0.50 ± 0.00 | 0.36 ± 0.00 |

### IEEE 118-bus seed robustness (test set, mean ± std over seeds)

| Model | Seeds | Secure % | Fallback % | Cost gap vs TSC-OPF % |
|---|---|---|---|---|
| mlp_opf | 3 | 0.00 ± 0.00 | 0.00 ± 0.00 | -2.17 ± 0.04 |
| mlp_tsc + certificate + fallback | 3 | 100.00 ± 0.00 | 20.63 ± 6.47 | 0.82 ± 0.11 |
| mlp_lam0.3 + certificate + fallback | 3 | 100.00 ± 0.00 | 4.54 ± 1.71 | 1.59 ± 0.03 |
| mlp_full + certificate + fallback | 3 | 100.00 ± 0.00 | 3.85 ± 0.39 | 2.26 ± 0.00 |
