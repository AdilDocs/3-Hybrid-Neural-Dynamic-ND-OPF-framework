### case39 – test (n=200)

| Method | Solved % | Secure % | Fallback % | Gap vs AC-OPF % | Gap vs TSC-OPF % | Mean latency (s) | Speed-up vs TSC-OPF |
|---|---|---|---|---|---|---|---|
| AC-OPF (PIPS) | 100.0 | 0.0 | – | 0.00 | -0.85 | 0.512 | 4.5× |
| TSC-OPF (iterative) | 100.0 | 100.0 | – | 0.86 | 0.00 | 2.309 | 1.0× |
| MLP-OPF (DeepOPF-style) | 100.0 | 0.0 | – | 0.11 | -0.75 | 0.044 | 52.0× |
| GNN-OPF | 99.5 | 0.0 | – | 0.35 | -0.50 | 0.073 | 31.8× |
| MLP-TSC | 100.0 | 97.0 | – | 0.96 | 0.09 | 0.032 | 71.5× |
| PI-GNN-TSC | 99.5 | 66.5 | – | 1.20 | 0.33 | 0.072 | 31.9× |
| PI-GNN + stab. loss | 100.0 | 91.5 | – | 1.34 | 0.47 | 0.068 | 33.9× |
| PI-MLP + stab. loss | 100.0 | 99.5 | – | 1.20 | 0.33 | 0.042 | 55.0× |
| PI-GNN + correction | 99.5 | 97.0 | – | 1.52 | 0.66 | 1.058 | 2.2× |
| PI-GNN + correction + fallback | 100.0 | 100.0 | 3.5 | 1.53 | 0.66 | 1.138 | 2.0× |
| Proposed (classical surrogate) | 99.5 | 99.5 | – | 1.78 | 0.91 | 0.377 | 6.1× |
| Proposed (classical surrogate) + fallback | 100.0 | 100.0 | 4.0 | 1.75 | 0.88 | 0.469 | 4.9× |
| Proposed | 100.0 | 99.0 | – | 1.40 | 0.54 | 0.408 | 5.7× |
| Proposed + fallback | 100.0 | 100.0 | 1.0 | 1.41 | 0.54 | 0.431 | 5.4× |
| Proposed (MLP backbone) | 100.0 | 99.5 | – | 1.21 | 0.34 | 0.131 | 17.6× |
| Proposed (MLP backbone) + fallback | 100.0 | 100.0 | 0.5 | 1.22 | 0.35 | 0.143 | 16.2× |
| Proposed (selected backbone) [mlp_lam0.3] | 99.0 | 98.5 | – | 1.13 | 0.27 | 0.143 | 16.1× |
| Proposed (selected backbone) + fallback [mlp_lam0.3] | 100.0 | 100.0 | 1.5 | 1.14 | 0.28 | 0.178 | 13.0× |
| MLP-TSC + certificate | 100.0 | 99.0 | – | 0.99 | 0.13 | 0.117 | 19.7× |
| MLP-TSC + certificate + fallback | 100.0 | 100.0 | 1.0 | 1.00 | 0.14 | 0.140 | 16.5× |

### case39 – ood (n=142)

| Method | Solved % | Secure % | Fallback % | Gap vs AC-OPF % | Gap vs TSC-OPF % | Mean latency (s) | Speed-up vs TSC-OPF |
|---|---|---|---|---|---|---|---|
| AC-OPF (PIPS) | 100.0 | 0.0 | – | 0.00 | -1.70 | 0.512 | 4.5× |
| TSC-OPF (iterative) | 100.0 | 75.4 | – | 2.25 | 0.00 | 2.309 | 1.0× |
| MLP-OPF (DeepOPF-style) | 91.5 | 0.0 | – | 0.10 | -1.62 | 0.044 | 52.0× |
| GNN-OPF | 89.4 | 0.0 | – | 0.10 | -1.62 | 0.073 | 31.8× |
| MLP-TSC | 91.5 | 38.0 | – | 0.96 | -0.74 | 0.032 | 71.5× |
| PI-GNN-TSC | 90.8 | 7.7 | – | 0.85 | -0.84 | 0.072 | 31.9× |
| PI-GNN + stab. loss | 92.3 | 32.4 | – | 1.00 | -0.69 | 0.068 | 33.9× |
| PI-MLP + stab. loss | 91.5 | 61.3 | – | 1.34 | -0.32 | 0.042 | 55.0× |
| PI-GNN + correction | 90.8 | 58.5 | – | 1.92 | 0.02 | 1.058 | 2.2× |
| PI-GNN + correction + fallback | 100.0 | 75.4 | 41.5 | 2.68 | 0.56 | 2.017 | 1.1× |
| Proposed (classical surrogate) | 90.8 | 64.8 | – | 2.28 | 0.50 | 0.377 | 6.1× |
| Proposed (classical surrogate) + fallback | 100.0 | 75.4 | 56.3 | 2.70 | 0.58 | 1.677 | 1.4× |
| Proposed | 92.3 | 59.9 | – | 1.78 | -0.13 | 0.408 | 5.7× |
| Proposed + fallback | 100.0 | 75.4 | 40.1 | 2.52 | 0.34 | 1.335 | 1.7× |
| Proposed (MLP backbone) | 91.5 | 62.7 | – | 1.77 | -0.08 | 0.131 | 17.6× |
| Proposed (MLP backbone) + fallback | 100.0 | 75.4 | 38.0 | 2.38 | 0.17 | 1.009 | 2.3× |
| Proposed (selected backbone) [mlp_lam0.3] | 92.3 | 59.2 | – | 1.71 | -0.17 | 0.143 | 16.1× |
| Proposed (selected backbone) + fallback [mlp_lam0.3] | 100.0 | 75.4 | 41.5 | 2.40 | 0.20 | 1.102 | 2.1× |
| MLP-TSC + certificate | 91.5 | 58.5 | – | 1.76 | -0.22 | 0.117 | 19.7× |
| MLP-TSC + certificate + fallback | 100.0 | 75.4 | 41.5 | 2.46 | 0.27 | 1.076 | 2.1× |

Latency source: single-thread benchmark (timing.py) for AC-OPF (PIPS), TSC-OPF (iterative), MLP-OPF (DeepOPF-style), GNN-OPF, MLP-TSC, GNN-TSC, PI-GNN-TSC, PI-GNN + stab. loss, PI-GNN + correction, Proposed (classical surrogate), Proposed, PI-MLP-TSC, PI-MLP + stab. loss, Proposed (MLP backbone), Proposed (selected backbone), MLP-TSC + certificate; other methods use evaluation-run wall time (2 jobs sharing 2 cores).

### case118 – test (n=147)

| Method | Solved % | Secure % | Fallback % | Gap vs AC-OPF % | Gap vs TSC-OPF % | Mean latency (s) | Speed-up vs TSC-OPF |
|---|---|---|---|---|---|---|---|
| AC-OPF (PIPS) | 100.0 | 0.0 | – | 0.00 | -2.41 | 0.749 | 6.1× |
| TSC-OPF (iterative) | 100.0 | 100.0 | – | 2.51 | 0.00 | 4.542 | 1.0× |
| MLP-OPF (DeepOPF-style) | 97.3 | 0.0 | – | 0.21 | -2.13 | 0.276 | 16.5× |
| GNN-OPF | 92.5 | 0.0 | – | 0.54 | -1.96 | 0.294 | 15.5× |
| MLP-TSC | 97.3 | 97.3 | – | 2.73 | 0.19 | 0.130 | 35.0× |
| PI-GNN-TSC | 97.3 | 49.0 | – | 2.72 | 0.19 | 0.162 | 28.0× |
| PI-GNN + stab. loss | 95.2 | 95.2 | – | 5.27 | 2.72 | 0.452 | 10.0× |
| PI-MLP + stab. loss | 96.6 | 96.6 | – | 4.77 | 2.33 | 0.468 | 9.7× |
| PI-GNN + correction | 97.3 | 67.3 | – | 4.78 | 2.18 | 3.789 | 1.2× |
| PI-GNN + correction + fallback | 100.0 | 100.0 | 34.0 | 3.89 | 1.34 | 5.334 | 0.9× |
| Proposed (classical surrogate) | 93.2 | 93.2 | – | 5.19 | 2.57 | 0.541 | 8.4× |
| Proposed (classical surrogate) + fallback | 100.0 | 100.0 | 6.8 | 4.96 | 2.40 | 0.850 | 5.3× |
| Proposed | 95.2 | 87.1 | – | 5.35 | 2.79 | 1.683 | 2.7× |
| Proposed + fallback | 100.0 | 100.0 | 14.3 | 5.13 | 2.57 | 2.331 | 1.9× |
| Proposed (MLP backbone) | 96.6 | 96.6 | – | 4.77 | 2.33 | 0.637 | 7.1× |
| Proposed (MLP backbone) + fallback | 100.0 | 100.0 | 3.4 | 4.82 | 2.25 | 0.791 | 5.7× |
| Proposed (selected backbone) [mlp_lam0.3] | 95.2 | 93.9 | – | 4.14 | 1.70 | 0.847 | 5.4× |
| Proposed (selected backbone) + fallback [mlp_lam0.3] | 100.0 | 100.0 | 6.1 | 4.11 | 1.56 | 1.125 | 4.0× |
| MLP-TSC + certificate | 97.3 | 89.8 | – | 3.80 | 1.23 | 3.004 | 1.5× |
| MLP-TSC + certificate + fallback | 100.0 | 100.0 | 14.3 | 3.46 | 0.92 | 3.653 | 1.2× |

### case118 – ood (n=98)

| Method | Solved % | Secure % | Fallback % | Gap vs AC-OPF % | Gap vs TSC-OPF % | Mean latency (s) | Speed-up vs TSC-OPF |
|---|---|---|---|---|---|---|---|
| AC-OPF (PIPS) | 100.0 | 0.0 | – | 0.00 | -8.16 | 0.749 | 6.1× |
| TSC-OPF (iterative) | 100.0 | 2.0 | – | 5.29 | 0.00 | 4.542 | 1.0× |
| MLP-OPF (DeepOPF-style) | 61.2 | 0.0 | – | 0.91 | -7.96 | 0.276 | 16.5× |
| GNN-OPF | 65.3 | 0.0 | – | 1.66 | -6.89 | 0.294 | 15.5× |
| MLP-TSC | 34.7 | 0.0 | – | 8.67 | 0.64 | 0.130 | 35.0× |
| PI-GNN-TSC | 76.5 | 0.0 | – | 6.71 | -0.79 | 0.162 | 28.0× |
| PI-GNN + stab. loss | 54.1 | 13.3 | – | 8.27 | 0.18 | 0.452 | 10.0× |
| PI-MLP + stab. loss | 7.1 | 0.0 | – | 7.67 | – | 0.468 | 9.7× |
| PI-GNN + correction | 76.5 | 2.0 | – | 7.22 | -0.39 | 3.789 | 1.2× |
| PI-GNN + correction + fallback | 100.0 | 2.0 | 100.0 | 5.29 | 0.00 | 8.331 | 0.5× |
| Proposed (classical surrogate) | 53.1 | 3.1 | – | 8.67 | -0.16 | 0.541 | 8.4× |
| Proposed (classical surrogate) + fallback | 100.0 | 4.1 | 98.0 | 5.31 | 0.00 | 4.990 | 0.9× |
| Proposed | 54.1 | 1.0 | – | 8.66 | -0.22 | 1.683 | 2.7× |
| Proposed + fallback | 100.0 | 2.0 | 100.0 | 5.29 | 0.00 | 6.224 | 0.7× |
| Proposed (MLP backbone) | 7.1 | 0.0 | – | 7.70 | – | 0.637 | 7.1× |
| Proposed (MLP backbone) + fallback | 100.0 | 2.0 | 100.0 | 5.29 | 0.00 | 5.179 | 0.9× |
| Proposed (selected backbone) [mlp_lam0.3] | 12.2 | 0.0 | – | 9.63 | – | 0.847 | 5.4× |
| Proposed (selected backbone) + fallback [mlp_lam0.3] | 100.0 | 2.0 | 100.0 | 5.29 | 0.00 | 5.389 | 0.8× |
| MLP-TSC + certificate | 34.7 | 0.0 | – | 8.77 | 1.32 | 3.004 | 1.5× |
| MLP-TSC + certificate + fallback | 100.0 | 2.0 | 100.0 | 5.29 | 0.00 | 7.546 | 0.6× |

Latency source: single-thread benchmark (timing.py) for AC-OPF (PIPS), TSC-OPF (iterative), MLP-OPF (DeepOPF-style), GNN-OPF, MLP-TSC, GNN-TSC, PI-GNN-TSC, PI-GNN + stab. loss, PI-GNN + correction, Proposed (classical surrogate), Proposed, PI-MLP-TSC, PI-MLP + stab. loss, Proposed (MLP backbone), Proposed (selected backbone), MLP-TSC + certificate; other methods use evaluation-run wall time (2 jobs sharing 2 cores).
