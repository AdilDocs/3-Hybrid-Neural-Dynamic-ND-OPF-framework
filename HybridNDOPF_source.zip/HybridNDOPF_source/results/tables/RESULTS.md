## case39

Dataset: `{"n_total": 1750, "n_opf_ok": 1742, "n_in_ok": 1600, "n_train": 1200, "n_val": 200, "n_test": 200, "n_ood": 142, "n_in_tsc_insecure": 0}`

### test

| Method | Feas. % | Secure % | Stable % | Cost gap vs AC-OPF % | Cost gap vs TSC-OPF % | median ρ_δ (rad) | Latency (s) | Speed-up vs TSC-OPF |
|---|---|---|---|---|---|---|---|---|
| AC-OPF (PIPS) | 100.0 | 0.0 | 0.0 | 0.00 | -0.85 | 3.14 | 0.491 | 4.4× |
| TSC-OPF (iterative) | 100.0 | 100.0 | 100.0 | 0.86 | 0.00 | 1.74 | 2.182 | 1.0× |
| MLP-OPF (DeepOPF-style) | 100.0 | 0.0 | 0.0 | 0.11 | -0.75 | 3.14 | 0.047 | 46.8× |
| GNN-OPF | 99.5 | 0.0 | 0.0 | 0.35 | -0.50 | 3.14 | 0.101 | 21.7× |
| MLP-TSC | 100.0 | 97.0 | 98.0 | 0.96 | 0.09 | 1.76 | 0.048 | 45.8× |
| GNN-TSC | 100.0 | 68.5 | 77.5 | 1.14 | 0.27 | 1.81 | 0.090 | 24.2× |
| PI-GNN-TSC | 99.5 | 66.5 | 74.5 | 1.20 | 0.33 | 1.85 | 0.094 | 23.2× |
| PI-GNN + stab. loss | 100.0 | 91.5 | 93.0 | 1.34 | 0.47 | 1.49 | 0.085 | 25.7× |
| PI-GNN + correction | 99.5 | 97.0 | 97.5 | 1.52 | 0.66 | 1.83 | 1.127 | 1.9× |
| Proposed (classical surrogate) | 99.5 | 99.5 | 99.5 | 1.78 | 0.91 | 1.34 | 0.390 | 5.6× |
| Proposed | 100.0 | 99.0 | 99.0 | 1.40 | 0.54 | 1.49 | 0.385 | 5.7× |
| PI-MLP-TSC | 100.0 | 95.0 | 98.5 | 1.01 | 0.15 | 1.76 | 0.046 | 47.4× |
| PI-MLP + stab. loss | 100.0 | 99.5 | 99.5 | 1.20 | 0.33 | 1.49 | 0.046 | 47.7× |
| Proposed (MLP backbone) | 100.0 | 99.5 | 99.5 | 1.21 | 0.34 | 1.49 | 0.165 | 13.2× |
| Proposed (selected backbone) | 99.0 | 98.5 | 98.5 | 1.13 | 0.27 | 1.56 | 0.153 | 14.2× |

| Method | median raw KCL residual (pu) | restoration iters | max KCL after restoration (pu) | max limit violation (pu) | corrected % | certified % | P(secure \| certified) % |
|---|---|---|---|---|---|---|---|
| MLP-OPF (DeepOPF-style) | 8.40e-01 | 1.4 | 1.0e-08 | 9.8e-05 | 0.0 | – | – |
| GNN-OPF | 1.97e+00 | 3.7 | 1.0e-08 | 9.8e-05 | 0.0 | – | – |
| MLP-TSC | 8.65e-01 | 1.6 | 9.5e-09 | 9.7e-05 | 0.0 | – | – |
| GNN-TSC | 1.88e+00 | 3.3 | 1.1e-08 | 9.7e-05 | 0.0 | – | – |
| PI-GNN-TSC | 6.36e-01 | 3.5 | 1.2e-08 | 1.0e-04 | 0.0 | – | – |
| PI-GNN + stab. loss | 6.74e-01 | 3.0 | 1.0e-08 | 9.8e-05 | 0.0 | – | – |
| PI-GNN + correction | 6.36e-01 | 3.5 | 1.2e-08 | 8.9e-05 | 37.5 | 96.5 | 100.0 |
| Proposed (classical surrogate) | 7.80e-01 | 3.2 | 9.6e-09 | 8.5e-05 | 23.0 | 96.0 | 100.0 |
| Proposed | 6.74e-01 | 3.0 | 1.0e-08 | 9.8e-05 | 9.0 | 99.0 | 100.0 |
| PI-MLP-TSC | 3.18e-01 | 2.4 | 8.4e-09 | 9.7e-05 | 0.0 | – | – |
| PI-MLP + stab. loss | 3.66e-01 | 2.3 | 9.9e-09 | 9.6e-05 | 0.0 | – | – |
| Proposed (MLP backbone) | 3.66e-01 | 2.3 | 9.9e-09 | 9.6e-05 | 0.5 | 99.5 | 100.0 |
| Proposed (selected backbone) | 3.23e-01 | 2.2 | 9.0e-09 | 9.9e-05 | 0.5 | 99.5 | 100.0 |

LaTeX rows:
```
AC-OPF (PIPS) & 100.0 & 0.0 & 0.00 & -0.85 & 3.14 & 0.491 \\
TSC-OPF (iterative) & 100.0 & 100.0 & 0.86 & 0.00 & 1.74 & 2.182 \\
MLP-OPF (DeepOPF-style) & 100.0 & 0.0 & 0.11 & -0.75 & 3.14 & 0.047 \\
GNN-OPF & 99.5 & 0.0 & 0.35 & -0.50 & 3.14 & 0.101 \\
MLP-TSC & 100.0 & 97.0 & 0.96 & 0.09 & 1.76 & 0.048 \\
GNN-TSC & 100.0 & 68.5 & 1.14 & 0.27 & 1.81 & 0.090 \\
PI-GNN-TSC & 99.5 & 66.5 & 1.20 & 0.33 & 1.85 & 0.094 \\
PI-GNN + stab. loss & 100.0 & 91.5 & 1.34 & 0.47 & 1.49 & 0.085 \\
PI-GNN + correction & 99.5 & 97.0 & 1.52 & 0.66 & 1.83 & 1.127 \\
Proposed (classical surrogate) & 99.5 & 99.5 & 1.78 & 0.91 & 1.34 & 0.390 \\
Proposed & 100.0 & 99.0 & 1.40 & 0.54 & 1.49 & 0.385 \\
PI-MLP-TSC & 100.0 & 95.0 & 1.01 & 0.15 & 1.76 & 0.046 \\
PI-MLP + stab. loss & 100.0 & 99.5 & 1.20 & 0.33 & 1.49 & 0.046 \\
Proposed (MLP backbone) & 100.0 & 99.5 & 1.21 & 0.34 & 1.49 & 0.165 \\
Proposed (selected backbone) & 99.0 & 98.5 & 1.13 & 0.27 & 1.56 & 0.153 \\
```

### ood

| Method | Feas. % | Secure % | Stable % | Cost gap vs AC-OPF % | Cost gap vs TSC-OPF % | median ρ_δ (rad) | Latency (s) | Speed-up vs TSC-OPF |
|---|---|---|---|---|---|---|---|---|
| AC-OPF (PIPS) | 100.0 | 0.0 | 0.0 | 0.00 | -1.70 | 3.14 | 0.445 | 5.7× |
| TSC-OPF (iterative) | 100.0 | 75.4 | 77.5 | 2.25 | 0.00 | 1.72 | 2.515 | 1.0× |
| MLP-OPF (DeepOPF-style) | 91.5 | 0.0 | 0.0 | 0.10 | -1.62 | 3.14 | 0.120 | 21.0× |
| GNN-OPF | 89.4 | 0.0 | 0.0 | 0.10 | -1.62 | 3.14 | 0.184 | 13.7× |
| MLP-TSC | 91.5 | 38.0 | 47.2 | 0.96 | -0.74 | 2.22 | 0.116 | 21.8× |
| GNN-TSC | 90.8 | 12.0 | 22.5 | 0.93 | -0.77 | 3.14 | 0.171 | 14.7× |
| PI-GNN-TSC | 90.8 | 7.7 | 15.5 | 0.85 | -0.84 | 3.14 | 0.183 | 13.8× |
| PI-GNN + stab. loss | 92.3 | 32.4 | 38.0 | 1.00 | -0.69 | 3.14 | 0.154 | 16.3× |
| PI-GNN + correction | 90.8 | 58.5 | 59.2 | 1.92 | 0.02 | 1.92 | 2.779 | 0.9× |
| Proposed (classical surrogate) | 90.8 | 64.8 | 67.6 | 2.28 | 0.50 | 1.52 | 1.413 | 1.8× |
| Proposed | 92.3 | 59.9 | 60.6 | 1.78 | -0.13 | 1.91 | 2.285 | 1.1× |
| PI-MLP-TSC | 91.5 | 50.0 | 55.6 | 1.14 | -0.56 | 1.91 | 0.094 | 26.8× |
| PI-MLP + stab. loss | 91.5 | 61.3 | 64.1 | 1.34 | -0.32 | 1.66 | 0.093 | 27.0× |
| Proposed (MLP backbone) | 91.5 | 62.7 | 63.4 | 1.77 | -0.08 | 1.66 | 1.428 | 1.8× |
| Proposed (selected backbone) | 92.3 | 59.2 | 59.2 | 1.71 | -0.17 | 1.79 | 1.502 | 1.7× |

| Method | median raw KCL residual (pu) | restoration iters | max KCL after restoration (pu) | max limit violation (pu) | corrected % | certified % | P(secure \| certified) % |
|---|---|---|---|---|---|---|---|
| MLP-OPF (DeepOPF-style) | 2.01e+00 | 4.5 | 9.9e-09 | 9.2e-05 | 0.0 | – | – |
| GNN-OPF | 4.85e+00 | 7.4 | 9.5e-09 | 9.9e-05 | 0.0 | – | – |
| MLP-TSC | 2.17e+00 | 4.6 | 7.8e-09 | 9.0e-05 | 0.0 | – | – |
| GNN-TSC | 4.51e+00 | 6.7 | 9.9e-09 | 9.7e-05 | 0.0 | – | – |
| PI-GNN-TSC | 1.03e+00 | 7.2 | 9.8e-09 | 9.9e-05 | 0.0 | – | – |
| PI-GNN + stab. loss | 9.55e-01 | 6.4 | 1.0e-08 | 9.7e-05 | 0.0 | – | – |
| PI-GNN + correction | 1.03e+00 | 7.2 | 9.8e-09 | 8.8e-05 | 83.1 | 58.5 | 100.0 |
| Proposed (classical surrogate) | 9.83e-01 | 7.3 | 6.8e-09 | 9.2e-05 | 79.6 | 43.7 | 100.0 |
| Proposed | 9.55e-01 | 6.4 | 1.0e-08 | 9.4e-05 | 60.6 | 59.9 | 100.0 |
| PI-MLP-TSC | 5.44e-01 | 5.3 | 9.0e-09 | 9.3e-05 | 0.0 | – | – |
| PI-MLP + stab. loss | 5.09e-01 | 5.3 | 6.9e-09 | 9.9e-05 | 0.0 | – | – |
| Proposed (MLP backbone) | 5.09e-01 | 5.3 | 7.6e-09 | 9.9e-05 | 31.0 | 62.0 | 100.0 |
| Proposed (selected backbone) | 5.36e-01 | 5.2 | 8.7e-09 | 9.8e-05 | 34.5 | 58.5 | 100.0 |

LaTeX rows:
```
AC-OPF (PIPS) & 100.0 & 0.0 & 0.00 & -1.70 & 3.14 & 0.445 \\
TSC-OPF (iterative) & 100.0 & 75.4 & 2.25 & 0.00 & 1.72 & 2.515 \\
MLP-OPF (DeepOPF-style) & 91.5 & 0.0 & 0.10 & -1.62 & 3.14 & 0.120 \\
GNN-OPF & 89.4 & 0.0 & 0.10 & -1.62 & 3.14 & 0.184 \\
MLP-TSC & 91.5 & 38.0 & 0.96 & -0.74 & 2.22 & 0.116 \\
GNN-TSC & 90.8 & 12.0 & 0.93 & -0.77 & 3.14 & 0.171 \\
PI-GNN-TSC & 90.8 & 7.7 & 0.85 & -0.84 & 3.14 & 0.183 \\
PI-GNN + stab. loss & 92.3 & 32.4 & 1.00 & -0.69 & 3.14 & 0.154 \\
PI-GNN + correction & 90.8 & 58.5 & 1.92 & 0.02 & 1.92 & 2.779 \\
Proposed (classical surrogate) & 90.8 & 64.8 & 2.28 & 0.50 & 1.52 & 1.413 \\
Proposed & 92.3 & 59.9 & 1.78 & -0.13 & 1.91 & 2.285 \\
PI-MLP-TSC & 91.5 & 50.0 & 1.14 & -0.56 & 1.91 & 0.094 \\
PI-MLP + stab. loss & 91.5 & 61.3 & 1.34 & -0.32 & 1.66 & 0.093 \\
Proposed (MLP backbone) & 91.5 & 62.7 & 1.77 & -0.08 & 1.66 & 1.428 \\
Proposed (selected backbone) & 92.3 & 59.2 & 1.71 & -0.17 & 1.79 & 1.502 \\
```

Conformal: `{"Proposed": {"qhat": 0.0, "n_cal": 1000, "test_coverage": 99.3}, "Proposed (classical surrogate)": {"qhat": 0.0, "n_cal": 995, "test_coverage": 100.0}, "Proposed (MLP backbone)": {"qhat": 0.0, "n_cal": 1000, "test_coverage": 98.5}}`

Surrogate validation: `{
 "classical_val": {
  "acc": 0.6355555555555555,
  "missed_alarm": 0.0,
  "false_alarm": 0.7130434782608696,
  "mae_rad": 0.38708138380650164
 },
 "node_val": {
  "acc": 0.9911111111111112,
  "missed_alarm": 0.0,
  "false_alarm": 0.017391304347826087,
  "mae_rad": 0.013684758451514184
 },
 "train_time_s": 1987.320847272873,
 "n_traj": 898
}`

## case118

Dataset: `{"n_total": 1320, "n_opf_ok": 1298, "n_in_ok": 1174, "n_train": 880, "n_val": 147, "n_test": 147, "n_ood": 98, "n_in_tsc_insecure": 26}`

### test

| Method | Feas. % | Secure % | Stable % | Cost gap vs AC-OPF % | Cost gap vs TSC-OPF % | median ρ_δ (rad) | Latency (s) | Speed-up vs TSC-OPF |
|---|---|---|---|---|---|---|---|---|
| AC-OPF (PIPS) | 100.0 | 0.0 | 0.0 | 0.00 | -2.41 | 3.14 | 2.003 | 6.0× |
| TSC-OPF (iterative) | 100.0 | 100.0 | 100.0 | 2.51 | 0.00 | 1.91 | 11.999 | 1.0× |
| MLP-OPF (DeepOPF-style) | 97.3 | 0.0 | 0.0 | 0.21 | -2.13 | 3.14 | 0.403 | 29.8× |
| GNN-OPF | 92.5 | 0.0 | 0.0 | 0.54 | -1.96 | 3.14 | 0.228 | 52.6× |
| MLP-TSC | 97.3 | 97.3 | 97.3 | 2.73 | 0.19 | 1.89 | 0.153 | 78.2× |
| GNN-TSC | 98.6 | 48.3 | 83.7 | 2.66 | 0.14 | 2.03 | 0.133 | 90.4× |
| PI-GNN-TSC | 97.3 | 49.0 | 83.0 | 2.72 | 0.19 | 1.99 | 0.143 | 83.9× |
| PI-GNN + stab. loss | 95.2 | 95.2 | 95.2 | 5.27 | 2.72 | 1.56 | 0.468 | 25.7× |
| PI-GNN + correction | 97.3 | 67.3 | 76.2 | 4.78 | 2.18 | 1.93 | 3.761 | 3.2× |
| Proposed (classical surrogate) | 93.2 | 93.2 | 93.2 | 5.19 | 2.57 | 1.56 | 0.511 | 23.5× |
| Proposed | 95.2 | 87.1 | 87.1 | 5.35 | 2.79 | 1.56 | 1.546 | 7.8× |
| PI-MLP-TSC | 96.6 | 95.9 | 96.6 | 2.83 | 0.29 | 1.90 | 0.159 | 75.5× |
| PI-MLP + stab. loss | 96.6 | 96.6 | 96.6 | 4.77 | 2.33 | 1.62 | 0.362 | 33.1× |
| Proposed (MLP backbone) | 96.6 | 96.6 | 96.6 | 4.77 | 2.33 | 1.62 | 0.549 | 21.8× |
| Proposed (selected backbone) | 95.2 | 93.9 | 93.9 | 4.14 | 1.70 | 1.70 | 0.746 | 16.1× |

| Method | median raw KCL residual (pu) | restoration iters | max KCL after restoration (pu) | max limit violation (pu) | corrected % | certified % | P(secure \| certified) % |
|---|---|---|---|---|---|---|---|
| MLP-OPF (DeepOPF-style) | 6.62e-01 | 4.7 | 1.0e-08 | 9.9e-05 | 0.0 | – | – |
| GNN-OPF | 3.44e+00 | 4.6 | 9.8e-09 | 9.9e-05 | 0.0 | – | – |
| MLP-TSC | 9.31e-01 | 3.6 | 5.6e-09 | 9.9e-05 | 0.0 | – | – |
| GNN-TSC | 3.36e+00 | 3.4 | 9.6e-09 | 7.5e-05 | 0.0 | – | – |
| PI-GNN-TSC | 1.03e+00 | 3.4 | 1.0e-08 | 9.9e-05 | 0.0 | – | – |
| PI-GNN + stab. loss | 1.04e+00 | 7.9 | 9.9e-09 | 8.6e-05 | 0.0 | – | – |
| PI-GNN + correction | 1.03e+00 | 3.4 | 9.5e-09 | 9.8e-05 | 57.1 | 67.3 | 100.0 |
| Proposed (classical surrogate) | 1.01e+00 | 7.8 | 1.0e-08 | 8.9e-05 | 0.0 | 100.0 | 100.0 |
| Proposed | 1.04e+00 | 7.9 | 9.9e-09 | 8.6e-05 | 15.0 | 89.8 | 100.0 |
| PI-MLP-TSC | 5.29e-01 | 4.0 | 1.0e-08 | 9.6e-05 | 0.0 | – | – |
| PI-MLP + stab. loss | 4.21e-01 | 7.2 | 9.4e-09 | 9.9e-05 | 0.0 | – | – |
| Proposed (MLP backbone) | 4.21e-01 | 7.2 | 9.4e-09 | 9.9e-05 | 0.0 | 99.3 | 100.0 |
| Proposed (selected backbone) | 3.74e-01 | 6.5 | 1.0e-08 | 9.9e-05 | 4.8 | 98.0 | 100.0 |

LaTeX rows:
```
AC-OPF (PIPS) & 100.0 & 0.0 & 0.00 & -2.41 & 3.14 & 2.003 \\
TSC-OPF (iterative) & 100.0 & 100.0 & 2.51 & 0.00 & 1.91 & 11.999 \\
MLP-OPF (DeepOPF-style) & 97.3 & 0.0 & 0.21 & -2.13 & 3.14 & 0.403 \\
GNN-OPF & 92.5 & 0.0 & 0.54 & -1.96 & 3.14 & 0.228 \\
MLP-TSC & 97.3 & 97.3 & 2.73 & 0.19 & 1.89 & 0.153 \\
GNN-TSC & 98.6 & 48.3 & 2.66 & 0.14 & 2.03 & 0.133 \\
PI-GNN-TSC & 97.3 & 49.0 & 2.72 & 0.19 & 1.99 & 0.143 \\
PI-GNN + stab. loss & 95.2 & 95.2 & 5.27 & 2.72 & 1.56 & 0.468 \\
PI-GNN + correction & 97.3 & 67.3 & 4.78 & 2.18 & 1.93 & 3.761 \\
Proposed (classical surrogate) & 93.2 & 93.2 & 5.19 & 2.57 & 1.56 & 0.511 \\
Proposed & 95.2 & 87.1 & 5.35 & 2.79 & 1.56 & 1.546 \\
PI-MLP-TSC & 96.6 & 95.9 & 2.83 & 0.29 & 1.90 & 0.159 \\
PI-MLP + stab. loss & 96.6 & 96.6 & 4.77 & 2.33 & 1.62 & 0.362 \\
Proposed (MLP backbone) & 96.6 & 96.6 & 4.77 & 2.33 & 1.62 & 0.549 \\
Proposed (selected backbone) & 95.2 & 93.9 & 4.14 & 1.70 & 1.70 & 0.746 \\
```

### ood

| Method | Feas. % | Secure % | Stable % | Cost gap vs AC-OPF % | Cost gap vs TSC-OPF % | median ρ_δ (rad) | Latency (s) | Speed-up vs TSC-OPF |
|---|---|---|---|---|---|---|---|---|
| AC-OPF (PIPS) | 100.0 | 0.0 | 0.0 | 0.00 | -8.16 | 3.14 | 1.222 | 10.3× |
| TSC-OPF (iterative) | 100.0 | 2.0 | 2.0 | 5.29 | 0.00 | 3.14 | 12.568 | 1.0× |
| MLP-OPF (DeepOPF-style) | 61.2 | 0.0 | 0.0 | 0.91 | -7.96 | 3.14 | 0.754 | 16.7× |
| GNN-OPF | 65.3 | 0.0 | 0.0 | 1.66 | -6.89 | 3.14 | 0.796 | 15.8× |
| MLP-TSC | 34.7 | 0.0 | 0.0 | 8.67 | 0.64 | 3.14 | 0.859 | 14.6× |
| GNN-TSC | 84.7 | 0.0 | 21.4 | 6.32 | -1.07 | 3.14 | 0.380 | 33.1× |
| PI-GNN-TSC | 76.5 | 0.0 | 13.3 | 6.71 | -0.79 | 3.14 | 0.517 | 24.3× |
| PI-GNN + stab. loss | 54.1 | 13.3 | 34.7 | 8.27 | 0.18 | 2.11 | 1.059 | 11.9× |
| PI-GNN + correction | 76.5 | 2.0 | 6.1 | 7.22 | -0.39 | 3.14 | 5.991 | 2.1× |
| Proposed (classical surrogate) | 53.1 | 3.1 | 18.4 | 8.67 | -0.16 | 3.14 | 4.482 | 2.8× |
| Proposed | 54.1 | 1.0 | 6.1 | 8.66 | -0.22 | 3.14 | 8.494 | 1.5× |
| PI-MLP-TSC | 33.7 | 0.0 | 0.0 | 9.35 | 0.77 | 3.14 | 0.937 | 13.4× |
| PI-MLP + stab. loss | 7.1 | 0.0 | 0.0 | 7.67 | – | 3.14 | 0.931 | 13.5× |
| Proposed (MLP backbone) | 7.1 | 0.0 | 0.0 | 7.70 | – | 3.14 | 6.406 | 2.0× |
| Proposed (selected backbone) | 12.2 | 0.0 | 2.0 | 9.63 | – | 3.14 | 8.082 | 1.6× |

| Method | median raw KCL residual (pu) | restoration iters | max KCL after restoration (pu) | max limit violation (pu) | corrected % | certified % | P(secure \| certified) % |
|---|---|---|---|---|---|---|---|
| MLP-OPF (DeepOPF-style) | 3.21e+00 | 9.7 | 9.1e-09 | 9.5e-05 | 0.0 | – | – |
| GNN-OPF | 9.01e+00 | 10.3 | 8.7e-09 | 9.7e-05 | 0.0 | – | – |
| MLP-TSC | 5.62e+00 | 11.6 | 9.9e-09 | 9.6e-05 | 0.0 | – | – |
| GNN-TSC | 5.02e+00 | 6.3 | 9.5e-09 | 9.8e-05 | 0.0 | – | – |
| PI-GNN-TSC | 2.81e+00 | 7.3 | 9.4e-09 | 9.8e-05 | 0.0 | – | – |
| PI-GNN + stab. loss | 4.18e+00 | 12.3 | 9.8e-09 | 8.4e-05 | 0.0 | – | – |
| PI-GNN + correction | 2.81e+00 | 7.3 | 9.0e-09 | 9.8e-05 | 76.5 | 0.0 | – |
| Proposed (classical surrogate) | 3.46e+00 | 12.1 | 9.3e-09 | 9.9e-05 | 52.0 | 2.0 | 100.0 |
| Proposed | 4.18e+00 | 12.3 | 9.8e-09 | 9.4e-05 | 54.1 | 0.0 | – |
| PI-MLP-TSC | 2.72e+00 | 11.7 | 1.0e-08 | 8.5e-05 | 0.0 | – | – |
| PI-MLP + stab. loss | 2.73e+00 | 12.4 | 8.2e-09 | 3.8e-10 | 0.0 | – | – |
| Proposed (MLP backbone) | 2.73e+00 | 12.4 | 6.9e-09 | 8.3e-06 | 7.1 | 2.0 | 100.0 |
| Proposed (selected backbone) | 2.76e+00 | 13.8 | 7.9e-09 | 9.3e-05 | 12.2 | 0.0 | – |

LaTeX rows:
```
AC-OPF (PIPS) & 100.0 & 0.0 & 0.00 & -8.16 & 3.14 & 1.222 \\
TSC-OPF (iterative) & 100.0 & 2.0 & 5.29 & 0.00 & 3.14 & 12.568 \\
MLP-OPF (DeepOPF-style) & 61.2 & 0.0 & 0.91 & -7.96 & 3.14 & 0.754 \\
GNN-OPF & 65.3 & 0.0 & 1.66 & -6.89 & 3.14 & 0.796 \\
MLP-TSC & 34.7 & 0.0 & 8.67 & 0.64 & 3.14 & 0.859 \\
GNN-TSC & 84.7 & 0.0 & 6.32 & -1.07 & 3.14 & 0.380 \\
PI-GNN-TSC & 76.5 & 0.0 & 6.71 & -0.79 & 3.14 & 0.517 \\
PI-GNN + stab. loss & 54.1 & 13.3 & 8.27 & 0.18 & 2.11 & 1.059 \\
PI-GNN + correction & 76.5 & 2.0 & 7.22 & -0.39 & 3.14 & 5.991 \\
Proposed (classical surrogate) & 53.1 & 3.1 & 8.67 & -0.16 & 3.14 & 4.482 \\
Proposed & 54.1 & 1.0 & 8.66 & -0.22 & 3.14 & 8.494 \\
PI-MLP-TSC & 33.7 & 0.0 & 9.35 & 0.77 & 3.14 & 0.937 \\
PI-MLP + stab. loss & 7.1 & 0.0 & 7.67 & – & 3.14 & 0.931 \\
Proposed (MLP backbone) & 7.1 & 0.0 & 7.70 & – & 3.14 & 6.406 \\
Proposed (selected backbone) & 12.2 & 0.0 & 9.63 & – & 3.14 & 8.082 \\
```

Conformal: `{"Proposed": {"qhat": 0.0, "n_cal": 710, "test_coverage": 98.91156462585035}, "Proposed (classical surrogate)": {"qhat": 0.011114084344051589, "n_cal": 730, "test_coverage": 96.3265306122449}, "Proposed (MLP backbone)": {"qhat": 0.0, "n_cal": 720, "test_coverage": 99.8639455782313}}`

Surrogate validation: `{
 "classical_val": {
  "acc": 0.8757575757575757,
  "missed_alarm": 0.0,
  "false_alarm": 0.2907801418439716,
  "mae_rad": 0.11133346027162729
 },
 "node_val": {
  "acc": 0.9424242424242424,
  "missed_alarm": 0.0,
  "false_alarm": 0.1347517730496454,
  "mae_rad": 0.0627226629791325
 },
 "train_time_s": 1596.2326354980469,
 "n_traj": 435
}`

## λ_stab sweep (39-bus, no correction)

| λ | cost gap vs AC-OPF % | secure % |
|---|---|---|
| 0 | 1.20 | 66.5 |
| 0.3 | 1.26 | 89.0 |
| 1 | 1.34 | 91.5 |
| 3 | 1.42 | 94.0 |
| 10 | 1.53 | 96.5 |

## Error propagation (39-bus, 100 test scenarios)

| Pg noise σ | correction | restored % | restoration iters | secure % | cost gap vs TSC-OPF % | latency (s) |
|---|---|---|---|---|---|---|
| 0% | no | 100.0 | 3.0 | 94.0 | 0.54 | 0.161 |
| 0% | yes | 100.0 | 3.0 | 99.0 | 0.57 | 0.290 |
| 2% | no | 99.0 | 2.9 | 95.0 | 0.62 | 0.148 |
| 2% | yes | 99.0 | 2.9 | 100.0 | 0.68 | 0.291 |
| 5% | no | 100.0 | 3.9 | 94.0 | 0.83 | 0.170 |
| 5% | yes | 100.0 | 3.9 | 99.0 | 0.88 | 0.316 |
| 10% | no | 100.0 | 5.0 | 83.0 | 1.25 | 0.187 |
| 10% | yes | 100.0 | 5.0 | 100.0 | 1.44 | 0.683 |
| 20% | no | 99.0 | 7.0 | 63.0 | 2.06 | 0.209 |
| 20% | yes | 99.0 | 7.0 | 98.0 | 2.93 | 0.923 |
