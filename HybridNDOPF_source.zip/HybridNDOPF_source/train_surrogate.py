"""Train the physics-structured neural-ODE surrogate on high-fidelity trajectories.
usage: python train_surrogate.py case39
"""
import sys
import time
import json
import numpy as np
import torch
from prep import Bundle
from models import Surrogate
from tscopf import DELTA_LIM
from config import ROOT, OUT

torch.manual_seed(0)


def batch(d, idx):
    return {k: (tuple(x[idx] for x in v) if isinstance(v, tuple) else v[idx]) for k, v in d.items()}


DT = 0.02  # overwritten per case in main()


def run(sur, d, tc, T=2.0, dt=None, record=False):
    return sur.simulate(d["delta0"], d["e0"], d["Pm"], d["Ypre"], d["Yf"], d["Yp"], tc, T=T, dt=dt or DT, record=record)


def sub(tr):
    """truth is sampled every 0.01 s; align with surrogate steps of DT"""
    k = int(round(DT / 0.01))
    return tr[:, k - 1::k]


def true_dev(tr, M):
    d = sub(tr)[:, :, :, 0]                         # (B, T, K, ng)
    coi = (d * M).sum(-1, keepdim=True) / M.sum()
    return (d - coi).permute(1, 0, 2, 3)       # (T, B, K, ng)


def evaluate(sur, d, tr, tc, M, bs=32):
    pred, true = [], []
    with torch.no_grad():
        for s in range(0, len(tr), bs):
            idx = torch.arange(s, min(s + bs, len(tr)))
            out = run(sur, batch(d, idx), tc)
            pred.append(out["dev"].abs().amax((0, 3)))
            true.append(true_dev(tr[idx], M).abs().amax((0, 3)))
    p, t = torch.cat(pred).flatten().numpy(), torch.cat(true).flatten().numpy()
    acc = ((p <= DELTA_LIM) == (t <= DELTA_LIM)).mean()
    sec_t = t <= DELTA_LIM
    miss = ((p <= DELTA_LIM) & ~sec_t).sum() / max((~sec_t).sum(), 1)   # insecure predicted secure
    fa = ((p > DELTA_LIM) & sec_t).sum() / max(sec_t.sum(), 1)          # secure predicted insecure
    both = (t < 2 * np.pi) & (p < 2 * np.pi)
    mae = np.abs(p - t)[both].mean() if both.any() else np.nan
    return dict(acc=float(acc), missed_alarm=float(miss), false_alarm=float(fa), mae_rad=float(mae)), p, t


def main(name, epochs=40):
    global DT
    B = Bundle(name)
    DT = B.c["sdt"]
    d, tr = B.traj_set()
    n = len(tr)
    perm = torch.randperm(n)
    ntr = int(0.85 * n)
    itr, iva = perm[:ntr], perm[ntr:]
    dtr, ttr = batch(d, itr), tr[itr]
    dva, tva = batch(d, iva), tr[iva]
    tc = B.c["tc"]
    M = torch.tensor(B.md.M)
    res = {}
    classical = Surrogate(B.md, learned=False)
    res["classical_val"], _, _ = evaluate(classical, dva, tva, tc, M)
    print("classical surrogate on val:", res["classical_val"], flush=True)

    sur = Surrogate(B.md, learned=True)
    opt = torch.optim.Adam(sur.parameters(), lr=3e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    bs = 16 if B.g.ng < 20 else 6
    t0 = time.time()
    for ep in range(epochs):
        sur.train()
        p = torch.randperm(ntr)
        tot = 0.0
        for s in range(0, ntr, bs):
            idx = p[s:s + bs]
            db, tb = batch(dtr, idx), ttr[idx]
            out = run(sur, db, tc, T=1.2, record=True)
            td = true_dev(tb, M)                                  # (T,B,K,ng)
            Tn = min(td.shape[0], out["dev"].shape[0])
            td, pdv = td[:Tn], out["dev"][:Tn]
            # mask after the true trajectory has clearly lost synchronism
            lost = (td.abs().amax(-1) > 2 * np.pi).float().cummax(0).values
            mask = (1 - lost).unsqueeze(-1)
            l_ang = (((pdv - td) ** 2) * mask).sum() / mask.sum().clamp(min=1) / B.g.ng
            e_true = sub(tb)[:, :Tn, :, 2].permute(1, 0, 2, 3)
            e_pred = out["traj"][:Tn, :, :, 2]
            l_e = (((e_pred - e_true) ** 2) * mask).sum() / mask.sum().clamp(min=1) / B.g.ng
            w_true = sub(tb)[:, :Tn, :, 1].permute(1, 0, 2, 3)
            w_pred = out["traj"][:Tn, :, :, 1]
            l_w = (((w_pred - w_true) ** 2) * mask).sum() / mask.sum().clamp(min=1) / B.g.ng
            loss = l_ang + 1.0 * l_e + 1e3 * l_w
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(sur.parameters(), 1.0)
            opt.step()
            tot += loss.item() * len(idx)
        sched.step()
        print(f"  epoch {ep + 1} loss {tot / ntr:.4f} {time.time() - t0:.0f}s", flush=True)
        if ep % 5 == 4 or ep == epochs - 1:
            sur.eval()
            m, _, _ = evaluate(sur, dva, tva, tc, M)
            print(f"ep {ep + 1} loss {tot / ntr:.4f} val {m}  {time.time() - t0:.0f}s", flush=True)
    res["node_val"], p, t = evaluate(sur, dva, tva, tc, M)
    res["train_time_s"] = time.time() - t0
    res["n_traj"] = int(n)
    torch.save(sur.state_dict(), f"{OUT}/{name}_surrogate.pt")
    json.dump(res, open(f"{OUT}/{name}_surrogate.json", "w"), indent=1)
    np.savez(f"{OUT}/{name}_surrogate_val.npz", pred=p, true=t)
    print(res)


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 40)
