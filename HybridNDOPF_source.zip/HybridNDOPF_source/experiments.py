"""Additional studies requested by the reviewers.
  sweep : weight of the stability term (trade-off economic cost vs transient security)
  noise : error propagation from the first stage (noise injected into predicted Pg)
usage: python experiments.py case39 sweep|noise
"""
import sys
import pickle
import numpy as np
from prep import Bundle
from pipeline import Pipeline, load_predictor, load_surrogate
from evaluate import run_learned
from config import OUT


def main(name, what):
    B = Bundle(name)
    path = f"{OUT}/{name}_extra.pkl"
    try:
        res = pickle.load(open(path, "rb"))
    except FileNotFoundError:
        res = {}
    conf = pickle.load(open(f"{OUT}/{name}_results.pkl", "rb"))
    qhat = conf.get(("_conformal", "node", "gnn_full"), conf.get(("_conformal", "node"), {"qhat": 0.0}))["qhat"]
    if what == "sweep":
        for lam, tag in [(0.0, "gnn_tsc_pf"), (0.3, "gnn_lam0.3"), (1.0, "gnn_full"), (3.0, "gnn_lam3"), (10.0, "gnn_lam10")]:
            pipe = Pipeline(B, load_predictor(B, tag), None, correct=False)
            res[("sweep", lam)] = run_learned(B, B.test, pipe, tag)
            print("sweep", lam, flush=True)
            pickle.dump(res, open(path, "wb"))
    if what == "noise":
        sur = load_surrogate(B, "node")
        net = load_predictor(B, "gnn_full")
        recs = B.test[:100]
        for sig in [0.0, 0.02, 0.05, 0.10, 0.20]:
            for corr in [False, True]:
                pipe = Pipeline(B, net, sur, correct=corr, qhat=qhat, noise=sig, seed=1)
                res[("noise", sig, corr)] = run_learned(B, recs, pipe, "gnn_full")
                print("noise", sig, corr, flush=True)
                pickle.dump(res, open(path, "wb"))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
