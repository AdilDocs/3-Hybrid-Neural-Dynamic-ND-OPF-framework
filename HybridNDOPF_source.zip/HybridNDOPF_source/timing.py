"""Clean latency benchmark: every method on the same scenarios, one process,
one thread, idle machine. usage: python timing.py case39 [n]
"""
import os
os.environ["OMP_NUM_THREADS"] = "1"
import sys
import time
import json
import numpy as np
import torch
torch.set_num_threads(1)
from prep import Bundle
from pipeline import Pipeline, load_predictor, load_surrogate
from tscopf import tsc_opf
from config import OUT


def main(name, n=40):
    B = Bundle(name)
    recs = B.test[:n]
    out = {}
    if os.environ.get("TIMING_ONLY"):
        prev = json.load(open(f"{OUT}/{name}_timing.json"))["raw"]
        out["AC-OPF (PIPS)"], out["TSC-OPF (iterative)"] = prev["AC-OPF (PIPS)"], prev["TSC-OPF (iterative)"]
    t = []
    for r in ([] if os.environ.get("TIMING_ONLY") else recs):
        t0 = time.perf_counter(); B.g.solve_opf(r["Pd"], r["Qd"]); t.append(time.perf_counter() - t0)
    if t:
        out["AC-OPF (PIPS)"] = t
    t = []
    for r in ([] if os.environ.get("TIMING_ONLY") else recs):
        t0 = time.perf_counter(); tsc_opf(B.g, B.md, r["Pd"], r["Qd"], B.conts); t.append(time.perf_counter() - t0)
    if t:
        out["TSC-OPF (iterative)"] = t
    res = json.load(open(f"{OUT}/{name}_qhat.json")) if os.path.exists(f"{OUT}/{name}_qhat.json") else {}
    from evaluate import METHODS
    only = os.environ.get("TIMING_ONLY")
    try:
        prev = json.load(open(f"{OUT}/{name}_timing.json"))["raw"]
    except Exception:
        prev = {}
    for m, (tag, kind, corr) in METHODS.items():
        if only and m not in only.split("|"):
            if m in prev:
                out[m] = prev[m]
            continue
        pipe = Pipeline(B, load_predictor(B, tag), load_surrogate(B, kind) if kind else None,
                        correct=corr, qhat=res.get(tag, 0.0))
        pipe(recs[0]["Pd"], recs[0]["Qd"])  # warm-up
        out[m] = [pipe(r["Pd"], r["Qd"])[1]["time"]["total"] for r in recs]
        print(name, m, np.mean(out[m]).round(3), flush=True)
    summ = {m: dict(mean=float(np.mean(v)), median=float(np.median(v)), p95=float(np.percentile(v, 95)))
            for m, v in out.items()}
    json.dump(dict(n=n, summary=summ, raw=out), open(f"{OUT}/{name}_timing.json", "w"), indent=1)
    print(json.dumps(summ, indent=1))


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 40)
