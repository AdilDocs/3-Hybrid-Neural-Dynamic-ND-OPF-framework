"""Security-constrained comparison ("best balance" evidence).

1. Per-method test metrics with 95 % bootstrap confidence intervals (scenario resampling).
2. Expected-cost index: generation cost + pi x (TSC-OPF cost) per insecure dispatch, reported
   as % above TSC-OPF, for penalties pi = 1 %, 10 %, 100 % of the scenario's hourly cost.
3. Pareto figure: latency vs cost gap; filled markers = 100 % secure (admissible).
4. Seed robustness (mean +/- std over seeds 0,1,2) if out/<case>_seeds.pkl exists.
Writes out/BALANCE.md and out/figures/fig_pareto.png.
"""
import os
import json
import pickle
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker
from config import OUT

plt.rcParams.update({"font.size": 8.5, "axes.grid": True, "grid.alpha": 0.3, "figure.dpi": 150})
RNG = np.random.default_rng(0)
NB = 2000
PIS = [0.01, 0.10, 1.00]
# label: (results key, uses certificate+fallback, timing key, colour, marker)
METHODS = {
    "AC-OPF (MIPS)": ("AC-OPF (PIPS)", False, "AC-OPF (PIPS)", "#2a78d6", "s"),
    "TSC-OPF (iterative)": ("TSC-OPF (iterative)", False, "TSC-OPF (iterative)", "#eb6834", "s"),
    "DeepOPF-style MLP": ("MLP-OPF (DeepOPF-style)", False, "MLP-OPF (DeepOPF-style)", "#1baf7a", "o"),
    "MLP imitating TSC-OPF": ("MLP-TSC", False, "MLP-TSC", "#eda100", "o"),
    "Proposed, λ=0": ("MLP-TSC + certificate", True, "MLP-TSC + certificate", "#9a9a94", "*"),
    "Proposed, λ=0.3 (selected)": ("Proposed (selected backbone)", True, "Proposed (selected backbone)", "#e34948", "*"),
    "Proposed, λ=1": ("Proposed (MLP backbone)", True, "Proposed (MLP backbone)", "#4a3aa7", "*"),
    "Proposed, GNN backbone, λ=1": ("Proposed", True, "Proposed", "#e87ba4", "*"),
}
SEEDMAP = {"mlp_opf": ("MLP-OPF (DeepOPF-style)", False), "mlp_tsc": ("MLP-TSC + certificate", True),
           "mlp_lam0.3": ("Proposed (selected backbone)", True), "mlp_full": ("Proposed (MLP backbone)", True)}


def per_scenario(R, key, fallback, s="test"):
    rows = R[(key, s)]
    tsc = {r["idx"]: r for r in R[("TSC-OPF (iterative)", s)]}
    sec, gap, fb = [], [], []
    for r in rows:
        ref = tsc[r["idx"]]
        accept = r["feasible"] and (not fallback or bool(r.get("certified")))
        if accept:
            sec.append(bool(r["secure"])); gap.append(r["cost"] / ref["cost"] - 1); fb.append(False)
        elif fallback:
            sec.append(bool(ref["secure"])); gap.append(0.0); fb.append(True)
        else:   # unsolved and no fallback: counted insecure, cost of the (non-converged) output
            sec.append(False); gap.append(r["cost"] / ref["cost"] - 1); fb.append(False)
    return np.array(sec), 100 * np.array(gap), np.array(fb)


def boot(x, f=np.mean):
    idx = RNG.integers(0, len(x), (NB, len(x)))
    v = np.array([f(x[i]) for i in idx])
    return f(x), np.percentile(v, 2.5), np.percentile(v, 97.5)


def clopper_pearson(k, n, a=0.05):
    """Exact binomial CI (in %); with 0 failures the lower bound is (a/2)^(1/n)."""
    from scipy.stats import beta
    lo = beta.ppf(a / 2, k, n - k + 1) if k > 0 else 0.0
    hi = beta.ppf(1 - a / 2, k + 1, n - k) if k < n else 1.0
    return 100 * k / n, 100 * lo, 100 * hi


def latency(timing, tkey, fbrate):
    t = np.array(timing["raw"][tkey]); tt = np.array(timing["raw"]["TSC-OPF (iterative)"])
    i = RNG.integers(0, len(t), (NB, len(t))); j = RNG.integers(0, len(tt), (NB, len(tt)))
    v = t[i].mean(1) + fbrate * tt[j].mean(1)
    return t.mean() + fbrate * tt.mean(), np.percentile(v, 2.5), np.percentile(v, 97.5)


def ci(m, lo, hi, d=2):
    return f"{m:.{d}f} [{lo:.{d}f}, {hi:.{d}f}]"


def main():
    md, pts = [], {}
    for name in ["case39", "case118"]:
        R = pickle.load(open(f"{OUT}/{name}_results.pkl", "rb"))
        T = json.load(open(f"{OUT}/{name}_timing.json"))
        n = len(R[("AC-OPF (PIPS)", "test")])
        md.append(f"### {name.replace('case', 'IEEE ')}-bus, test set (n={n}), 95 % CIs (secure: Clopper-Pearson; others: bootstrap)\n")
        md.append("| Method | Secure % | Fallback % | Cost gap vs TSC-OPF % | Mean latency s | Expected-cost gap, π=1 % | π=10 % | π=100 % |")
        md.append("|---|---|---|---|---|---|---|---|")
        pts[name] = []
        for lab, (key, fb, tkey, col, mk) in METHODS.items():
            sec, gap, fbk = per_scenario(R, key, fb)
            S = clopper_pearson(int(sec.sum()), len(sec))
            G = boot(gap)
            L = latency(T, tkey, fbk.mean())
            E = [boot(gap + 100 * p * (~sec)) for p in PIS]
            md.append(f"| {lab}{' + fallback' if fb else ''} | {ci(*S, 1)} | {100 * fbk.mean():.1f} | {ci(*G)} | "
                      f"{ci(*L, 3)} | {E[0][0]:.2f} | {E[1][0]:.2f} | {E[2][0]:.2f} |")
            pts[name].append((lab, L[0], G[0], S[0], col, mk))
        md.append("")
    # ---- seed robustness
    for name in ["case39", "case118"]:
        p = f"{OUT}/{name}_seeds.pkl"
        if not os.path.exists(p):
            continue
        Sd = pickle.load(open(p, "rb"))
        R = pickle.load(open(f"{OUT}/{name}_results.pkl", "rb"))
        md.append(f"### {name.replace('case', 'IEEE ')}-bus seed robustness (test set, mean ± std over seeds)\n")
        md.append("| Model | Seeds | Secure % | Fallback % | Cost gap vs TSC-OPF % |")
        md.append("|---|---|---|---|---|")
        for base, (key, fb) in SEEDMAP.items():
            vals = []
            runs = [(0, R[(key, "test")])] + [(s, v["rows"]) for (b, s), v in sorted(Sd.items()) if b == base]
            for s, rows in runs:
                Rt = dict(R); Rt[("_tmp", "test")] = rows
                sec, gap, fbk = per_scenario(Rt, "_tmp", fb)
                vals.append((100 * sec.mean(), 100 * fbk.mean(), gap.mean()))
            v = np.array(vals)
            sd = lambda k: f"{v[:, k].mean():.2f} ± {v[:, k].std(ddof=1) if len(v) > 1 else 0:.2f}"
            md.append(f"| {base}{' + certificate + fallback' if fb else ''} | {len(v)} | {sd(0)} | {sd(1)} | {sd(2)} |")
        md.append("")
    open(f"{OUT}/BALANCE.md", "w").write("\n".join(md))
    print("\n".join(md))
    # ---- Pareto figure
    fig, axs = plt.subplots(1, 2, figsize=(7.6, 3.6))
    handles = {}
    for ax, (name, P) in zip(axs, pts.items()):
        for lab, lat, gap, sec, col, mk in P:
            ok = sec >= 99.95
            h = ax.scatter(lat, gap, marker=mk, s=110 if mk == "*" else 42, facecolor=col if ok else "white",
                           edgecolor=col, linewidth=1.6, zorder=3)
            handles[lab] = h
            if not ok:
                ax.annotate(f"{sec:.0f}% secure", (lat, gap), textcoords="offset points", xytext=(6, -3),
                            fontsize=6.5, color="#555555")
        ax.set_xscale("log")
        ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
        tk = [t for t in [0.03, 0.1, 0.3, 1, 3, 10] if 0.5 * min(p[1] for p in P) <= t <= 2 * max(p[1] for p in P)]
        ax.set_xticks(tk); ax.set_xticklabels([f"{t:g}" for t in tk])
        ax.axhline(0, color="#bbbbbb", lw=0.8, zorder=1)
        ax.set_xlabel("Mean latency per scenario (s, single CPU thread)")
        ax.set_ylabel("Cost gap vs TSC-OPF (%)")
        ax.set_title(("(a) " if name == "case39" else "(b) ") + name.replace("case", "IEEE ") + "-bus, test set", fontsize=9)
    fig.legend([handles[k] for k in METHODS], list(METHODS), loc="lower center", ncol=3, fontsize=6.8, frameon=False)
    fig.text(0.5, 0.215, "Filled: 100 % transient-secure (admissible). Hollow: violates security in some scenarios.",
             ha="center", fontsize=7, color="#444444")
    fig.tight_layout(rect=(0, 0.24, 1, 1))
    fig.savefig(f"{OUT}/figures/fig_pareto.png")


if __name__ == "__main__":
    main()
