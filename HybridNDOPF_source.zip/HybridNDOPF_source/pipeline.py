"""Inference pipeline of the revised Hybrid ND-OPF and of the learned baselines.

  1. predictor (GNN / MLP)                    -> (Pg, Vm, Va)
  2. AC feasibility restoration (projection)  -> exact AC power-flow state within limits
  3. surrogate screening + conformal margin   -> per-contingency predicted max |δ−δ_COI|
  4. stability-aware correction (only if not certified): gradient re-dispatch through
     the implicit steady-state layer and the neural-ODE surrogate, then re-restoration
"""
import time
import numpy as np
import torch
from models import (BusGNN, MLPPredictor, Surrogate, steady_state, electrical_power,
                    soft_max_dev, dyn_tensors, stack_dyn)
from tscopf import DELTA_LIM
from config import ROOT, OUT

DELTA_TARGET = DELTA_LIM - 0.3


def load_predictor(B, tag):
    ck = torch.load(f"{OUT}/{B.name}_{tag}.pt")
    net = BusGNN(B.gt) if ck["args"]["model"] == "gnn" else MLPPredictor(B.gt)
    net.load_state_dict(ck["state"])
    net.eval()
    return net


def load_surrogate(B, kind="node"):
    sur = Surrogate(B.md, learned=(kind == "node"))
    if kind == "node":
        sur.load_state_dict(torch.load(f"{OUT}/{B.name}_surrogate.pt"))
    sur.eval()
    for p in sur.parameters():
        p.requires_grad_(False)
    return sur


class Pipeline:
    def __init__(self, B, net, sur=None, correct=False, qhat=0.0, max_rounds=3, steps=8, noise=0.0, seed=0, bisect=4):
        self.B, self.net, self.sur = B, net, sur
        self.correct, self.qhat = correct, qhat
        self.max_rounds, self.steps, self.bisect = max_rounds, steps, bisect
        self.noise = noise
        self.rng = np.random.default_rng(seed)

    # -------------------------------------------------------------- screening
    def screen(self, st, Pd, Qd):
        B = self.B
        dyn = stack_dyn([dyn_tensors(B.g, B.md, st, Pd, Qd, B.conts)])
        with torch.no_grad():
            out = self.sur.simulate(dyn["delta0"], dyn["e0"], dyn["Pm"], dyn["Ypre"], dyn["Yf"], dyn["Yp"],
                                    B.c["tc"], T=B.c["Tscreen"], dt=B.c["idt"])
        pred = out["dev"].abs().amax((0, 3))[0].numpy()
        return pred, dyn

    # ------------------------------------------------------------- correction
    def correction(self, st, dyn, Pd, Qd):
        """Sensitivity-based stability re-dispatch (one linearisation per round):
        severity s_k(P) of every flagged contingency and its Jacobian ds_k/dP are
        obtained by back-propagating through the neural-ODE surrogate and the
        implicit steady-state layer; then a small QP finds the cheapest generation
        shift that brings the linearised severities below the target."""
        B = self.B
        g = B.g
        slack = g.slack_gen
        ns = [i for i in range(g.ng) if i != slack]
        p = dyn["Pm"].clone().requires_grad_(True)
        d = steady_state(p, dyn["e0"], *dyn["Ypre"], dyn["delta0"], slack)
        Pm, _ = electrical_power(d, dyn["e0"], *dyn["Ypre"])
        out = self.sur.simulate(d, dyn["e0"], Pm, dyn["Ypre"], dyn["Yf"], dyn["Yp"], B.c["tc"], T=B.c["Tscreen"], dt=B.c["idt"])
        a = out["dev"].abs()
        a = torch.where(a < np.pi, a, np.pi + torch.log1p((a - np.pi).clamp(min=0)))   # C1 extension
        T_, _, K, n = a.shape
        s = torch.logsumexp(20.0 * a.permute(1, 2, 0, 3).reshape(1, K, -1), -1)[0] / 20.0
        target = DELTA_TARGET - self.qhat
        flag = [k for k in range(K) if s[k].item() > target - 0.15]
        if not flag:
            return None
        J = np.stack([torch.autograd.grad(s[k], p, retain_graph=True)[0][0].numpy() for k in flag])
        sv = s.detach().numpy()[flag]
        P0 = Pm.detach()[0].numpy()
        Jn = J[:, ns]
        c = g.c1 * g.base + 2 * g.c2 * g.base ** 2 * P0          # marginal cost $/h per pu
        lin = c[ns] - c[slack]
        tr = 0.25 * np.maximum(g.Pmax[ns], 0.5)
        lb = np.maximum(g.Pmin[ns] - P0[ns], -tr)
        ub = np.minimum(g.Pmax[ns] - P0[ns], tr)
        # slack limits: Pmin_s <= P0_s - sum(dp) <= Pmax_s ; severity rows: sv + Jn dp <= target
        G = np.vstack([Jn, np.ones((1, len(ns))), -np.ones((1, len(ns)))])
        h = np.concatenate([target - sv, [P0[slack] - g.Pmin[slack]], [g.Pmax[slack] - P0[slack]]])
        x = linear_qp(lin / max(np.abs(lin).max(), 1e-9), 1e-3, G, h, lb, ub)
        if x is None:
            return None
        Pnew = P0.copy()
        Pnew[ns] += x
        Pnew[slack] -= x.sum()
        return Pnew

    # ---------------------------------------------------------------- forward
    def __call__(self, Pd, Qd):
        B, g = self.B, self.B.g
        tm = {}
        t0 = time.perf_counter()
        with torch.no_grad():
            Vm, Va, Pg = self.net(torch.tensor(Pd)[None], torch.tensor(Qd)[None])
            dP, dQ = B.gt.kcl(Vm, Va, Pg, torch.tensor(Pd)[None], torch.tensor(Qd)[None])
        Vm, Va, Pg = Vm[0].numpy(), Va[0].numpy(), Pg[0].numpy()
        tm["predict"] = time.perf_counter() - t0
        raw_kcl = float(max(dP.abs().max(), dQ.abs().max()))
        if self.noise > 0:   # error-propagation study: corrupt the first-stage output
            Pg = np.clip(Pg * (1 + self.noise * self.rng.standard_normal(g.ng)), g.Pmin, g.Pmax)
        Vg = Vm[g.gbus]
        t1 = time.perf_counter()
        st = g.restore(Pg, Vg, Pd, Qd)
        tm["restore"] = time.perf_counter() - t1
        info = dict(raw_kcl=raw_kcl, restore_iters=st["iters"], restore_ok=st["success"], rounds=0,
                    restore_hist=list(st["hist"]),
                    certified=None, pred_dev=None)
        tm["screen"] = tm["correct"] = 0.0
        if self.sur is not None:
            t2 = time.perf_counter()
            pred, dyn = self.screen(st, Pd, Qd)
            tm["screen"] += time.perf_counter() - t2
            info["pred_dev_first"] = pred
            cert = bool(np.all(pred + self.qhat <= DELTA_LIM))
            rounds = 0
            st0 = st
            while self.correct and not cert and rounds < self.max_rounds and st["success"]:
                t3 = time.perf_counter()
                Pnew = self.correction(st, dyn, Pd, Qd)
                if Pnew is None:
                    tm["correct"] += time.perf_counter() - t3
                    break
                st_new = g.restore(Pnew, np.abs(st["V"][g.gbus]), Pd, Qd)
                tm["correct"] += time.perf_counter() - t3
                rounds += 1
                if not st_new["success"]:
                    break
                st = st_new
                t2 = time.perf_counter()
                pred, dyn = self.screen(st, Pd, Qd)
                tm["screen"] += time.perf_counter() - t2
                cert = bool(np.all(pred + self.qhat <= DELTA_LIM))
            if self.correct and rounds > 0 and cert:
                # certified line search back towards the (cheaper) first-stage dispatch
                t3 = time.perf_counter()
                Pa, Pb = st0["Pg"].copy(), st["Pg"].copy()
                lo, hi = 0.0, 1.0
                for _ in range(self.bisect):
                    mid = 0.5 * (lo + hi)
                    st_m = g.restore(Pa + mid * (Pb - Pa), np.abs(st["V"][g.gbus]), Pd, Qd)
                    if not st_m["success"]:
                        lo = mid
                        continue
                    pm, _ = self.screen(st_m, Pd, Qd)
                    if np.all(pm + self.qhat <= DELTA_LIM):
                        hi, st, pred = mid, st_m, pm
                    else:
                        lo = mid
                tm["correct"] += time.perf_counter() - t3
            info.update(rounds=rounds, certified=cert, pred_dev=pred)
        tm["total"] = time.perf_counter() - t0
        info["time"] = tm
        return st, info


def linear_qp(c, rho, G, h, lb, ub):
    """min c'x + rho/2 ||x||^2  s.t. Gx <= h, lb <= x <= ub, with elastic severity rows."""
    import clarabel
    import scipy.sparse as sp
    n, m = len(c), len(h)
    # elastic slacks on all rows keep the QP feasible; heavy penalty
    Pm = sp.block_diag([sp.eye(n) * rho, sp.eye(m) * 1e-6], format="csc")
    q = np.concatenate([c, 1e3 * np.ones(m)])
    A = sp.vstack([sp.hstack([sp.csc_matrix(G), -sp.eye(m)]),
                   sp.hstack([sp.csc_matrix((m, n)), -sp.eye(m)]),
                   sp.hstack([sp.eye(n), sp.csc_matrix((n, m))]),
                   sp.hstack([-sp.eye(n), sp.csc_matrix((n, m))])], format="csc")
    b = np.concatenate([h, np.zeros(m), ub, -lb])
    st = clarabel.DefaultSettings(); st.verbose = False
    sol = clarabel.DefaultSolver(sp.triu(Pm, format="csc"), q, A, b, [clarabel.NonnegativeConeT(len(b))], st)
    r = sol.solve()
    if str(r.status) not in ("Solved", "AlmostSolved"):
        return None
    return np.array(r.x[:n])
