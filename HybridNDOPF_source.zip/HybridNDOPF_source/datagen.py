"""Scenario generation: loads -> AC-OPF -> high-fidelity stability -> TSC-OPF labels,
plus recorded trajectories for training the dynamic surrogate.

usage: python datagen.py case39 [workers]
"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys
import time
import pickle
import numpy as np
from multiprocessing import Pool

from config import CFG, LOCAL_SIGMA, ROOT
from grid import load_grid
from dynamics import MachineData, Contingency, simulate
from tscopf import tsc_opf

_G = {}


def _setup(name):
    g = load_grid(name)
    md = MachineData(g)
    c = CFG[name]
    conts = [Contingency(g, b, l, c["tc"]) for b, l in c["conts"]]
    _G.update(g=g, md=md, conts=conts, name=name)


def sample_load(g, rng, lo, hi):
    a = rng.uniform(lo, hi)
    f = a * np.clip(1 + LOCAL_SIGMA * rng.standard_normal(g.nb), 0.8, 1.2)
    return g.Pd0 * f, g.Qd0 * f, a


def compact(st):
    return dict(V=st["V"].astype(np.complex128), Pg=st["Pg"], Qg=st["Qg"])


def traj_of(st, Pd, Qd, stride=2):
    g, md, conts = _G["g"], _G["md"], _G["conts"]
    r = simulate(g, md, st, Pd, Qd, conts, model="flux", T=2.0, record=True)
    tr = r["traj"][stride - 1::stride].astype(np.float32)   # (T, K, 4, ng), dt*stride
    return dict(traj=tr, max_dev=r["max_dev"], dt=0.005 * stride)


def work(args):
    idx, split, seed, want_traj = args
    g, md, conts = _G["g"], _G["md"], _G["conts"]
    c = CFG[_G["name"]]
    rng = np.random.default_rng(seed)
    lo, hi = c["load_ood"] if split == "ood" else c["load_in"]
    Pd, Qd, a = sample_load(g, rng, lo, hi)
    rec = dict(idx=idx, split=split, alpha=a, Pd=Pd, Qd=Qd, ok=False)
    opf = g.solve_opf(Pd, Qd)
    if opf is None:
        return rec
    t0 = time.perf_counter()
    r_opf = simulate(g, md, opf, Pd, Qd, conts, model="flux")
    t_sim = time.perf_counter() - t0
    rec.update(ok=True, opf=compact(opf), opf_Vg=opf["Vg"], opf_cost=opf["cost"], opf_time=opf["time"],
               opf_maxdev=r_opf["max_dev"], sim_time=t_sim)
    tsc = tsc_opf(g, md, Pd, Qd, conts)
    if tsc is not None:
        rec.update(tsc=compact(tsc["st"]), tsc_Vg=tsc["st"]["Vg"], tsc_cost=tsc["st"]["cost"],
                   tsc_time=tsc["time"], tsc_secure=tsc["secure"], tsc_iters=tsc["iters"],
                   tsc_nopf=tsc["n_opf"], tsc_maxdev=tsc["max_dev"])
    if want_traj and tsc is not None:
        trajs = [traj_of(opf, Pd, Qd), traj_of(tsc["st"], Pd, Qd)]
        # intermediate dispatch: blend + noise, restored to AC feasibility
        w = rng.uniform(0.2, 0.8)
        Pg = w * opf["Pg"] + (1 - w) * tsc["st"]["Pg"]
        Pg = Pg * (1 + 0.04 * rng.standard_normal(g.ng))
        Vg = w * opf["Vg"] + (1 - w) * tsc["st"]["Vg"]
        rr = g.restore(np.clip(Pg, g.Pmin, g.Pmax), Vg, Pd, Qd)
        states = [opf, tsc["st"]]
        if rr["success"]:
            trajs.append(traj_of(rr, Pd, Qd))
            states.append(rr)
        rec["traj"] = trajs
        rec["traj_states"] = [compact(s) for s in states]
    return rec


def main(name, workers=2):
    c = CFG[name]
    jobs = []
    rng = np.random.default_rng({"case39": 39, "case118": 118}[name])
    seeds = rng.integers(0, 2 ** 31, c["n_in"] + c["n_ood"])
    for i in range(c["n_in"]):
        jobs.append((i, "in", int(seeds[i]), i < c["n_traj"]))
    for j in range(c["n_ood"]):
        i = c["n_in"] + j
        jobs.append((i, "ood", int(seeds[i]), False))
    out = []
    t0 = time.time()
    with Pool(workers, initializer=_setup, initargs=(name,)) as pool:
        for k, rec in enumerate(pool.imap_unordered(work, jobs, chunksize=4)):
            out.append(rec)
            if (k + 1) % 50 == 0:
                print(f"{name}: {k + 1}/{len(jobs)}  {time.time() - t0:.0f}s", flush=True)
    out.sort(key=lambda r: r["idx"])
    os.makedirs(f"{ROOT}/data", exist_ok=True)
    with open(f"{ROOT}/data/{name}.pkl", "wb") as fh:
        pickle.dump(out, fh, protocol=4)
    print("done", name, len(out), f"{time.time() - t0:.0f}s")


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 2)
