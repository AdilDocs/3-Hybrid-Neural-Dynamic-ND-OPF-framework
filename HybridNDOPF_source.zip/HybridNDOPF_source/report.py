"""Tables (markdown + LaTeX) and figures from the evaluation results."""
import os
import json
import pickle
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from config import OUT
from tscopf import DELTA_LIM

ORDER = ["AC-OPF (PIPS)", "TSC-OPF (iterative)", "MLP-OPF (DeepOPF-style)", "GNN-OPF", "MLP-TSC",
         "GNN-TSC", "PI-GNN-TSC", "PI-GNN + stab. loss", "PI-GNN + correction",
         "Proposed (classical surrogate)", "Proposed", "PI-MLP-TSC", "PI-MLP + stab. loss",
         "Proposed (MLP backbone)", "Proposed (selected backbone)"]
FIG = f"{OUT}/figures"
os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({"font.size": 9, "axes.grid": True, "grid.alpha": 0.3, "figure.dpi": 150})


def by_idx(rows):
    return {r["idx"]: r for r in rows}


def summarize(R, m, s):
    rows = R.get((m, s))
    if rows is None:
        return None
    opf = by_idx(R[("AC-OPF (PIPS)", s)])
    tsc = by_idx(R[("TSC-OPF (iterative)", s)])
    n = len(rows)
    feas = [r for r in rows if r["feasible"]]
    gap_opf = [100 * (r["cost"] / opf[r["idx"]]["cost"] - 1) for r in feas if opf[r["idx"]]["feasible"]]
    ref_ok = [r for r in feas if tsc[r["idx"]]["feasible"] and tsc[r["idx"]].get("secure")]
    gap_tsc = [100 * (r["cost"] / tsc[r["idx"]]["cost"] - 1) for r in ref_ok]
    sec = [r["feasible"] and r.get("secure", False) for r in rows]     # unsolved counts as not secure
    stab = [r["feasible"] and r.get("stable", False) for r in rows]
    rho = [min(max(r["max_dev"]), np.pi) for r in feas]
    lat = [r["time"]["total"] for r in feas]
    out = dict(n=n, feas=100 * len(feas) / n, secure=100 * np.mean(sec), stable=100 * np.mean(stab),
               gap_opf=np.mean(gap_opf) if gap_opf else np.nan,
               gap_tsc=np.mean(gap_tsc) if gap_tsc else np.nan,
               gap_tsc_secure=np.mean([g for g, r in zip(gap_tsc, ref_ok) if r.get("secure")]) if gap_tsc else np.nan,
               rho_med=np.median(rho) if rho else np.nan,
               latency=np.mean(lat) if lat else np.nan, latency_p95=np.percentile(lat, 95) if lat else np.nan,
               kcl=np.max([r["kcl"] for r in feas]) if feas else np.nan,
               maxviol=np.max([r["maxviol"] for r in feas]) if feas else np.nan)
    if "raw_kcl" in rows[0]:
        out["raw_kcl"] = np.median([r["raw_kcl"] for r in rows])
        out["restore_iters"] = np.mean([r["restore_iters"] for r in feas])
        out["corrected"] = 100 * np.mean([r["rounds"] > 0 for r in rows])
        cert = [r for r in rows if r.get("certified")]
        if rows[0].get("certified") is not None:
            out["certified"] = 100 * len(cert) / n
            out["cert_precision"] = 100 * np.mean([r["secure"] for r in cert]) if cert else np.nan
    return out


def fmt(v, d=2):
    return "–" if v is None or (isinstance(v, float) and np.isnan(v)) else f"{v:.{d}f}"


def main_table(R, name, s):
    tsc_lat = summarize(R, "TSC-OPF (iterative)", s)["latency"]
    lines = ["| Method | Feas. % | Secure % | Stable % | Cost gap vs AC-OPF % | Cost gap vs TSC-OPF % | median ρ_δ (rad) | Latency (s) | Speed-up vs TSC-OPF |",
             "|---|---|---|---|---|---|---|---|---|"]
    tex = []
    for m in ORDER:
        S = summarize(R, m, s)
        if S is None:
            continue
        sp = tsc_lat / S["latency"] if S["latency"] else np.nan
        lines.append(f"| {m} | {fmt(S['feas'],1)} | {fmt(S['secure'],1)} | {fmt(S['stable'],1)} | {fmt(S['gap_opf'])} | "
                     f"{fmt(S['gap_tsc'])} | {fmt(S['rho_med'])} | {fmt(S['latency'],3)} | {fmt(sp,1)}× |")
        tex.append(f"{m} & {fmt(S['feas'],1)} & {fmt(S['secure'],1)} & {fmt(S['gap_opf'])} & {fmt(S['gap_tsc'])} & "
                   f"{fmt(S['rho_med'])} & {fmt(S['latency'],3)} \\\\")
    return "\n".join(lines), "\n".join(tex)


def learned_table(R, s):
    lines = ["| Method | median raw KCL residual (pu) | restoration iters | max KCL after restoration (pu) | max limit violation (pu) | corrected % | certified % | P(secure \\| certified) % |",
             "|---|---|---|---|---|---|---|---|"]
    for m in ORDER[2:]:
        S = summarize(R, m, s)
        if S is None:
            continue
        lines.append(f"| {m} | {S['raw_kcl']:.2e} | {fmt(S['restore_iters'],1)} | {S['kcl']:.1e} | {S['maxviol']:.1e} | "
                     f"{fmt(S['corrected'],1)} | {fmt(S.get('certified'),1)} | {fmt(S.get('cert_precision'),1)} |")
    return "\n".join(lines)


KEY = {  # fixed categorical slots (validated reference palette), never cycled
    "AC-OPF (PIPS)": "#2a78d6", "TSC-OPF (iterative)": "#eb6834", "MLP-OPF (DeepOPF-style)": "#1baf7a",
    "MLP-TSC": "#eda100", "PI-GNN + correction": "#e87ba4", "Proposed": "#008300",
    "Proposed (MLP backbone)": "#4a3aa7", "Proposed (selected backbone)": "#e34948"}
GREY = "#9a9a94"


def fig_tradeoff(Rs):
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.7), squeeze=False)
    handles = {}
    for ax, (name, R) in zip(axs[0], Rs.items()):
        for m in ORDER:
            S = summarize(R, m, "test")
            if S is None or S["secure"] < 50:
                continue   # OPF-trained methods: 0 % secure, listed in the table
            col = KEY.get(m, GREY)
            mk = "s" if "OPF (" in m else ("*" if m.startswith("Proposed") and m in KEY else "o")
            h = ax.scatter(S["gap_tsc"], S["secure"], marker=mk, s=90 if mk == "*" else 34, color=col,
                           edgecolor="white", linewidth=1.0, zorder=3 if m in KEY else 2)
            handles[m if m in KEY else "Ablations (see table)"] = h
        ax.axvline(0, color="#bbbbbb", lw=0.8)
        ax.set_xlabel("Cost gap vs TSC-OPF (%)")
        ax.set_ylabel("Secure dispatches, learned only (%)")
        ax.set_title(name.replace("case", "IEEE ") + "-bus, test set", fontsize=9)
    order = [k for k in KEY if k in handles] + (["Ablations (see table)"] if "Ablations (see table)" in handles else [])
    fig.legend([handles[k] for k in order], order, loc="lower center", ncol=3, fontsize=7, frameon=False)
    fig.tight_layout(rect=(0, 0.17, 1, 1))
    fig.savefig(f"{FIG}/fig_cost_security.png")
    plt.close(fig)


def fig_restoration(Rs):
    fig, ax = plt.subplots(figsize=(3.6, 2.7))
    for (name, R), col in zip(Rs.items(), ["#2a78d6", "#eb6834"]):
        rows = R[("Proposed (selected backbone)", "test")]
        conv = np.array([len(r["restore_hist"]) - 1 if r["feasible"] else np.inf for r in rows])
        it = np.arange(0, 16)
        ax.step(it, [100 * np.mean(conv <= k) for k in it], where="post", color=col, lw=2,
                label=name.replace("case", "IEEE ") + f"-bus (n={len(rows)})")
    ax.set_xlabel("Restoration iteration (Newton PF + projection QP)", fontsize=8)
    ax.set_xticks(range(0, 16, 3))
    ax.set_ylabel("Scenarios restored to tolerance (%)")
    ax.set_ylim(0, 102)
    ax.legend(fontsize=7, loc="lower right")
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig_restoration.png")
    plt.close(fig)


def fig_surrogate(names):
    fig, axs = plt.subplots(1, len(names), figsize=(3.4 * len(names), 3.0), squeeze=False)
    for ax, name in zip(axs[0], names):
        z = np.load(f"{OUT}/{name}_surrogate_val.npz")
        p, t = np.minimum(z["pred"], 4.0), np.minimum(z["true"], 4.0)
        ax.scatter(t, p, s=8, color="#2a78d6", alpha=0.6, edgecolor="none")
        ax.plot([0, 4], [0, 4], color="#555555", lw=1)
        ax.axvline(DELTA_LIM, color="#e34948", ls="--", lw=1)
        ax.axhline(DELTA_LIM, color="#e34948", ls="--", lw=1)
        ax.text(DELTA_LIM + 0.05, 0.2, "security limit", color="#333333", fontsize=7)
        ax.set_xlabel("High-fidelity max |δ−δ_COI| (rad, capped at 4)")
        ax.set_ylabel("Neural-ODE prediction (rad)")
        ax.set_title(("(a) " if name == "case39" else "(b) ") + name.replace("case", "IEEE ") + "-bus, held-out trajectories", fontsize=8.5)
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig_surrogate_parity.png")
    plt.close(fig)


def fig_sweep(X):
    if not any(k[0] == "sweep" for k in X):
        return None
    lams = sorted(k[1] for k in X if k[0] == "sweep")
    sec, gap = [], []
    R = pickle.load(open(f"{OUT}/case39_results.pkl", "rb"))
    opf = by_idx(R[("AC-OPF (PIPS)", "test")])
    for l in lams:
        rows = X[("sweep", l)]
        sec.append(100 * np.mean([r["secure"] for r in rows]))
        gap.append(np.mean([100 * (r["cost"] / opf[r["idx"]]["cost"] - 1) for r in rows if r["feasible"]]))
    fig, ax = plt.subplots(figsize=(3.6, 2.8))
    ax.plot(gap, sec, "o-", color="#2a78d6", lw=2, ms=6)
    for l, x, y in zip(lams, gap, sec):
        ax.annotate(f"λ={l:g}", (x, y), textcoords="offset points", xytext=(4, -10), fontsize=7)
    ax.set_xlabel("Cost increase vs AC-OPF (%)")
    ax.set_ylabel("Secure without correction (%)")
    ax.set_title("Stability-loss weight (GNN backbone, IEEE 39-bus)", fontsize=8.5)
    ax.margins(x=0.15)
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig_lambda_sweep.png")
    plt.close(fig)
    return list(zip(lams, gap, sec))


def noise_table(X, R):
    keys = sorted(k for k in X if k[0] == "noise")
    if not keys:
        return None
    tsc = by_idx(R[("TSC-OPF (iterative)", "test")])
    lines = ["| Pg noise σ | correction | restored % | restoration iters | secure % | cost gap vs TSC-OPF % | latency (s) |",
             "|---|---|---|---|---|---|---|"]
    for k in keys:
        rows = X[k]
        f = [r for r in rows if r["feasible"]]
        lines.append(f"| {100*k[1]:.0f}% | {'yes' if k[2] else 'no'} | {100*len(f)/len(rows):.1f} | "
                     f"{np.mean([r['restore_iters'] for r in f]):.1f} | {100*np.mean([r['secure'] for r in rows]):.1f} | "
                     f"{np.mean([100*(r['cost']/tsc[r['idx']]['cost']-1) for r in f]):.2f} | "
                     f"{np.mean([r['time']['total'] for r in f]):.3f} |")
    return "\n".join(lines)


def conformal_info(R):
    out = {}
    for key, m in [(("_conformal", "node", "gnn_full"), "Proposed"),
                   (("_conformal", "classical", "gnn_full_cl"), "Proposed (classical surrogate)"),
                   (("_conformal", "node", "mlp_full"), "Proposed (MLP backbone)")]:
        c = R.get(key)
        if c:
            rows = R.get((m, "test"), [])
            # empirical per-contingency coverage on the (post-correction) test dispatches
            cov = [t <= min(p, 2 * np.pi) + c["qhat"] or t > 2 * np.pi and p > 2 * np.pi
                   for r in rows if "pred_dev" in r for p, t in zip(r["pred_dev"], r["max_dev"])]
            out[m] = dict(qhat=c["qhat"], n_cal=len(c["residuals"]), test_coverage=100 * np.mean(cov) if cov else None)
    return out


def main():
    Rs, md = {}, []
    for name in ["case39", "case118"]:
        p = f"{OUT}/{name}_results.pkl"
        if os.path.exists(p):
            Rs[name] = pickle.load(open(p, "rb"))
    for name, R in Rs.items():
        md.append(f"## {name}\n\nDataset: `{json.dumps(R['_stats'])}`\n")
        for s in ["test", "ood"]:
            t, tex = main_table(R, name, s)
            md.append(f"### {s}\n\n{t}\n\n{learned_table(R, s)}\n")
            md.append("LaTeX rows:\n```\n" + tex + "\n```\n")
        md.append(f"Conformal: `{json.dumps(conformal_info(R))}`\n")
        sj = f"{OUT}/{name}_surrogate.json"
        if os.path.exists(sj):
            md.append(f"Surrogate validation: `{open(sj).read().strip()}`\n")
    if Rs:
        fig_tradeoff(Rs)
        fig_restoration(Rs)
        fig_surrogate([n for n in Rs if os.path.exists(f"{OUT}/{n}_surrogate_val.npz")])
    xp = f"{OUT}/case39_extra.pkl"
    if os.path.exists(xp):
        X = pickle.load(open(xp, "rb"))
        sw = fig_sweep(X)
        if sw:
            md.append("## λ_stab sweep (39-bus, no correction)\n\n| λ | cost gap vs AC-OPF % | secure % |\n|---|---|---|\n" +
                      "\n".join(f"| {l:g} | {g:.2f} | {s:.1f} |" for l, g, s in sw) + "\n")
        nt = noise_table(X, Rs["case39"])
        if nt:
            md.append("## Error propagation (39-bus, 100 test scenarios)\n\n" + nt + "\n")
    open(f"{OUT}/RESULTS.md", "w").write("\n".join(md))
    print("\n".join(md))


if __name__ == "__main__":
    main()
