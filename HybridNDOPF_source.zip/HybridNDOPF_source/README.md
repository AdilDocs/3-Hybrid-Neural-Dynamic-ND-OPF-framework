# Revised Hybrid ND-OPF: code and experiments

This is a from-scratch implementation of a revised *stability-aware learning OPF*,
written in response to the reviewer comments on the original Hybrid ND-OPF paper.
It runs on CPU only and uses PyTorch, PYPOWER (MATPOWER's MIPS/PIPS interior-point
solver), OSQP/Clarabel, NumPy and SciPy.

## What changed with respect to the original manuscript

| Original component | Revised component | Why |
|---|---|---|
| Synthetic data on "IEEE" cases, IPOPT/TSAT labels | **PGLib-OPF** `case39_epri`, `case118_ieee`. AC-OPF labels come from MATPOWER's interior-point solver; the reference costs match PGLib exactly. Transient labels come from our own RMS simulator. | Reproducible, standard OPF benchmark, and real cost data (R2-3). |
| Swing eq. `dδ/dt = ω_s(ω − ω_s)` | `dδ/dt = ω_b Δω`, `2H dΔω/dt = Pm − Pe − DΔω`, with all states reported as COI deviations | Fixes the unit error (R2-6). |
| High-fidelity reference | 4-state machine model: swing + flux decay (one-axis) + static AVR with limits. Kron-reduced network with constant-impedance loads. 3-phase bolted fault, cleared by tripping a line. | Independent "ground truth" for closed-loop validation (R1-2). |
| NODE (slow) + FNO (fast EM transients) | **Physics-structured neural ODE**. The swing equation and network are kept exactly, and only the flux/excitation closure is learned from high-fidelity trajectories. FNO is removed. | Phasor/RMS tools (TSAT-type) do not resolve EM transients, so the FNO had no consistent target. This removes the NODE–FNO coupling problem (R1-3, R2-6). |
| KKT projection (KCL + V only) | **AC feasibility restoration**: (i) Newton power flow (KCL to 1e-8 pu), then (ii) a projection QP over all limits (slack Pg, all Qg, PQ-bus V, branch MVA), linearised with implicit-function-theorem sensitivities, repeated to tolerance 1e-4 pu. | Complete constraint model (R2) and measurable convergence (Fig. restoration). |
| Lyapunov hinge on ṙ ≤ 0 with absolute states | (a) Training uses a **smooth security penalty** on the surrogate's max COI angle deviation. (b) Certification uses a **transient energy function** (Lyapunov) in COI deviation coordinates relative to the post-fault SEP, with the PEBS critical energy. Certified iff V(t_cl) < V_cr. Its precision and recall are measured against the simulator. | Correct Lyapunov formulation (R2-2). No claim of a guarantee: reliability is reported. |
| Single weighted loss | Supervised loss on TSC-OPF labels + λ_pf · power-flow residual + λ_stab · security penalty, back-propagated through an **implicit steady-state layer** (Pe(δ)=Pm, unrolled Newton) and the neural ODE. A λ sweep is reported. | Shows how the layers interact and the trade-off curve (R1-1). |
| — | **Per-dispatch trust**: surrogate screening with a split-conformal margin, gradient-based corrective redispatch (QP), and a certified line search back toward the cheaper dispatch. Every final dispatch is re-simulated with the high-fidelity model. | Per-solution credibility plus closed-loop validation (R1-2). |

## Pipeline at inference

1. The predictor (GNN or MLP) outputs (Pg, Vm, Va).
2. AC feasibility restoration gives an exact AC state within limits.
3. Neural-ODE screening of the K critical contingencies. Certified if max|δ−δ_COI| + q̂ ≤ 2.0 rad.
4. If not certified: sensitivity-based redispatch (QP) through the surrogate, then restoration again. Up to 3 rounds, followed by bisection back toward the first-stage dispatch.

## Files

| File | Role |
|---|---|
| `config.py` | Contingencies, clearing times, load ranges, sizes |
| `grid.py` | PGLib loader, Newton PF, AC-OPF (PIPS), feasibility restoration |
| `dynamics.py` | Classical and high-fidelity (flux-decay + AVR) multi-machine simulator |
| `tscopf.py` | Conventional TSC-OPF baseline (iterative rescheduling with the simulator in the loop) |
| `datagen.py` | Scenarios → AC-OPF → simulation → TSC-OPF labels and trajectories |
| `models.py` | Bus GNN, MLP (DeepOPF-style), implicit steady-state layer, physics-structured neural ODE |
| `train_surrogate.py` | Trains the neural ODE on high-fidelity trajectories |
| `train_predictor.py` | Trains predictors (labels, PF residual, stability penalty) |
| `pipeline.py` | Inference pipeline (restore, screen, correct, line search) |
| `certificate.py`, `tef_eval.py` | Energy-function (Lyapunov/PEBS) certificate and its validation |
| `evaluate.py` | All methods on test/OOD, high-fidelity re-simulation |
| `experiments.py` | λ sweep, error-propagation study |
| `timing.py` | Single-thread latency benchmark |
| `report.py`, `fig_*.py` | Tables (`out/RESULTS.md`) and figures (`out/figures`) |

## Reproduce

```
bash run_all.sh        # ~10 h on 2 CPU cores
```

## Headline results (test sets; full tables in `out/HEADLINE.md` and `out/RESULTS.md`)

Operational protocol: a learned dispatch is accepted only if (i) AC restoration converged
and (ii) the neural-ODE certificate holds. Otherwise the scenario falls back to TSC-OPF.
Across 4,409 certified dispatches in all runs (all variants, both systems, test and OOD sets, three seeds), **0** were insecure in the high-fidelity simulator.

| System | Method | Secure % | Fallback % | Cost gap vs TSC-OPF % | Mean latency (s) | Speed-up |
|---|---|---|---|---|---|---|
| 39-bus | AC-OPF (no stability) | 0.0 | – | −0.85 | 0.51 | – |
| 39-bus | TSC-OPF (iterative) | 100 | – | 0 | 2.31 | 1× |
| 39-bus | Selected (PI-MLP, λ=0.3) + certificate + fallback | 100 | 1.5 | +0.28 | 0.18 | 13× |
| 39-bus | MLP-TSC + certificate + fallback (λ=0) | 100 | 1.0 | +0.14 | 0.14 | 16.5× |
| 118-bus | AC-OPF (no stability) | 0.0 | – | −2.41 | 0.75 | – |
| 118-bus | TSC-OPF (iterative) | 100 | – | 0 | 4.54 | 1× |
| 118-bus | Selected (PI-MLP, λ=0.3) + certificate + fallback | 100 | 6.1 | +1.56 | 1.13 | 4.0× |
| 118-bus | MLP-TSC + certificate + fallback (λ=0) | 100 | 14.3 | +0.92 | 3.65 | 1.2× |
| 118-bus | PI-MLP, λ=1 + certificate + fallback | 100 | 3.4 | +2.25 | 0.79 | 5.7× |

Known limitations: in the stressed OOD sets, many learned dispatches are rejected (39-bus: about 40% fallback).
On 118-bus OOD the TSC-OPF reference itself is secure in only 2% of cases. Test sets contain only
scenarios for which TSC-OPF found a secure dispatch (all on 39-bus; 1,174 of 1,200 on 118-bus).
The IEEE-118 dynamic data are typical values, not a standard data set. Latency is single-thread CPU.

## Security-constrained comparison (`out/BALANCE.md`, `out/figures/fig_pareto.png`)

- 95% CIs: Clopper-Pearson for the secure rate, bootstrap for cost and latency.
- Expected-cost index: generation cost plus a penalty π (as a share of hourly cost) for each insecure dispatch.
- Seed robustness: 3 seeds per main model.

## Folder layout

- `*.py`, `run_all.sh`: the full source code. Run from this folder.
- `data/raw/`: the PGLib-OPF case files. Scenario data (`data/*.pkl`) are regenerated by `datagen.py`.
- `results/figures/`, `results/tables/`: the figures and tables reported in the paper. A fresh run writes them to `out/`.
- Install the dependencies with `pip install -r requirements.txt`.
