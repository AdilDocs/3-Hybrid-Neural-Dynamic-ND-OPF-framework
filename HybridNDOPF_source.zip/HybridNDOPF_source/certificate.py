"""Per-dispatch stability certificate: transient energy function (TEF) with the
potential-energy-boundary-surface (PEBS) method, written in COI deviation
coordinates relative to the post-fault stable equilibrium point (SEP).

This is a *direct-method* Lyapunov-type certificate for the classical model with
transfer conductances (path-dependent term integrated numerically). It is not a
rigorous proof for the high-fidelity model; its reliability is measured against
the high-fidelity simulator (precision / recall of the 'certified secure' label).
"""
import numpy as np
from scipy.optimize import fsolve
from dynamics import OMEGA_B, init_machines, reduced_matrices


def _pe(theta, E, Y):
    Ec = E * np.exp(1j * theta)
    return (Ec * np.conj(Y @ Ec)).real


def post_fault_sep(theta0, E, Pm, Y, M):
    """Solve P_m - P_e(θ) - (M_i/M_T) P_COI = 0 with Σ M θ = 0."""
    MT = M.sum()

    def F(th_r):
        th = np.append(th_r, -(M[:-1] @ th_r) / M[-1])
        mis = Pm - _pe(th, E, Y)
        pcoi = mis.sum()
        return (mis - M / MT * pcoi)[:-1]

    th0 = theta0 - (M @ theta0) / MT
    sol, info, ier, _ = fsolve(F, th0[:-1], full_output=True)
    th = np.append(sol, -(M[:-1] @ sol) / M[-1])
    ok = ier == 1 and np.abs(F(sol)).max() < 1e-6 and np.abs(np.angle(np.exp(1j * (th - th0)))).max() < 1.5
    return th, ok


def tef_certificate(grid, md, st, Pd, Qd, conts, T_fault=1.0, dt=0.002):
    """Returns per-contingency (certified_secure, normalised energy margin)."""
    init = init_machines(grid, md, st, Pd, Qd)
    Ypre, Yf, Yp = reduced_matrices(grid, md, init, conts)
    E, Pm = init["Eq"], init["Pm"]
    M = 2 * md.H / OMEGA_B          # inertia in TEF units (θ in rad, t in s)
    MT = M.sum()
    out_cert, out_margin = [], []
    for k, c in enumerate(conts):
        Y = Yp[k]
        G, B = Y.real, Y.imag
        C = np.outer(E, E) * B
        D = np.outer(E, E) * G
        np.fill_diagonal(C, 0)
        np.fill_diagonal(D, 0)
        Pi = Pm - E ** 2 * np.diag(G)
        ths, ok = post_fault_sep(init["delta"], E, Pm, Y, M)
        if not ok:
            out_cert.append(False); out_margin.append(-1.0); continue
        iu = np.triu_indices(len(E), 1)

        def vp_increment(th_a, th_b):
            # potential-energy increment between consecutive points (trapezoid for path term)
            dth = th_b - th_a
            lin = -Pi @ dth
            tij_a = th_a[:, None] - th_a[None, :]
            tij_b = th_b[:, None] - th_b[None, :]
            dsum = (dth[:, None] + dth[None, :])
            path = 0.5 * (D * (np.cos(tij_a) + np.cos(tij_b)) * dsum)[iu].sum()
            cosd = -(C * (np.cos(tij_b) - np.cos(tij_a)))[iu].sum()
            return lin + cosd + path

        # sustained-fault trajectory with the classical model (COI frame)
        Yfk = Yf[k]
        th = init["delta"] - (M @ init["delta"]) / MT
        w = np.zeros_like(th)

        def acc(th):
            mis = Pm - _pe(th, E, Yfk)
            return (mis - M / MT * mis.sum()) / M

        vp = 0.0
        # path from SEP to pre-fault point (straight line, 20 sub-steps)
        prev = ths
        for s in np.linspace(0, 1, 21)[1:]:
            cur = ths + s * (th - ths)
            vp += vp_increment(prev, cur)
            prev = cur
        vp_hist, ke_hist = [vp], [0.0]
        nsteps = int(T_fault / dt)
        tc_step = int(round(c.tc / dt))
        for n in range(nsteps):
            # velocity-Verlet integration of the fault-on dynamics
            a0 = acc(th)
            th_new = th + dt * w + 0.5 * dt ** 2 * a0
            w = w + 0.5 * dt * (a0 + acc(th_new))
            vp += vp_increment(th, th_new)
            th = th_new
            vp_hist.append(vp)
            ke_hist.append(0.5 * (M * w ** 2).sum())
            if n > tc_step and vp < vp_hist[-2]:
                break  # past the PEBS crossing (first maximum of V_p)
        vp_hist = np.array(vp_hist)
        Vcr = vp_hist.max()
        Vtc = ke_hist[tc_step] + vp_hist[tc_step]
        margin = (Vcr - Vtc) / max(abs(Vcr), 1e-9)
        out_cert.append(bool(Vtc < Vcr))
        out_margin.append(float(margin))
    return np.array(out_cert), np.array(out_margin)
