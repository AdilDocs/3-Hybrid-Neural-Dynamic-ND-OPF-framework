"""Figure: Lyapunov (transient energy) function in COI *deviation* coordinates relative to
the post-fault stable equilibrium, along the classical-model trajectory, for the AC-OPF
dispatch (insecure) and the TSC-OPF / proposed dispatch (secure) of one test scenario.

V(θ, ω) = ½ Σ M_i ω̃_i²  +  V_p(θ̃),  V_p from the post-fault network (path term integrated
numerically). After clearing, dV/dt = −Σ D_i ω̃_i² ≤ 0 up to integration error; the
critical energy V_cr is obtained with the PEBS method. Certified iff V(t_cl) < V_cr.
"""
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from prep import Bundle
from dynamics import OMEGA_B, init_machines, reduced_matrices
from certificate import post_fault_sep, tef_certificate, _pe
from config import OUT

plt.rcParams.update({"font.size": 8.5, "axes.grid": True, "grid.alpha": 0.3, "figure.dpi": 150})


def energy_trace(B, st, Pd, Qd, k, T=3.0, dt=0.001):
    g, md = B.g, B.md
    c = B.conts[k]
    init = init_machines(g, md, st, Pd, Qd)
    Ypre, Yf, Yp = reduced_matrices(g, md, init, [c])
    E, Pm = init["Eq"], init["Pm"]
    M = 2 * md.H / OMEGA_B
    Dm = md.D / OMEGA_B
    MT = M.sum()
    Y = Yp[0]
    C = np.outer(E, E) * Y.imag; Dg = np.outer(E, E) * Y.real
    np.fill_diagonal(C, 0); np.fill_diagonal(Dg, 0)
    Pi = Pm - E ** 2 * np.diag(Y.real)
    iu = np.triu_indices(len(E), 1)
    ths, ok = post_fault_sep(init["delta"], E, Pm, Y, M)

    def dvp(a, b):
        d = b - a
        ta, tb = a[:, None] - a[None, :], b[:, None] - b[None, :]
        return (-Pi @ d - (C * (np.cos(tb) - np.cos(ta)))[iu].sum()
                + 0.5 * (Dg * (np.cos(ta) + np.cos(tb)) * (d[:, None] + d[None, :]))[iu].sum())

    def acc(th, w, Yk):
        mis = Pm - _pe(th, E, Yk) - Dm * w
        return (mis - M / MT * mis.sum()) / M

    th = init["delta"] - (M @ init["delta"]) / MT
    w = np.zeros_like(th)
    vp = 0.0
    prev = ths
    for s in np.linspace(0, 1, 41)[1:]:
        cur = ths + s * (th - ths); vp += dvp(prev, cur); prev = cur
    ts, V, dev = [0.0], [vp], [np.abs(th - ths).max()]
    n = int(T / dt); ntc = int(round(c.tc / dt))
    for i in range(n):
        Yk = Yf[0] if i < ntc else Y
        a0 = acc(th, w, Yk)
        thn = th + dt * w + 0.5 * dt ** 2 * a0
        wh = w + 0.5 * dt * a0
        w = wh + 0.5 * dt * acc(thn, wh, Yk)
        vp += dvp(th, thn); th = thn
        ts.append((i + 1) * dt); V.append(0.5 * (M * w ** 2).sum() + vp); dev.append(np.abs(th).max())
        if np.abs(th).max() > 3 * np.pi:
            break
    cert, margin = tef_certificate(g, md, st, Pd, Qd, [c])
    # critical energy recomputed by the certificate routine: V_cr = V(t_cl) / (1 - margin)
    Vtc = V[ntc]
    Vcr = Vtc / (1 - margin[0]) if margin[0] < 1 else np.nan
    return np.array(ts), np.array(V), Vcr, bool(cert[0]), float(margin[0]), ok


def main(name="case39"):
    B = Bundle(name)
    # pick a test scenario whose TSC-OPF dispatch is certified by the TEF
    import json
    tef = json.load(open(f"{OUT}/{name}_tef.json"))["rows"]
    recs = {x["idx"]: x for x in B.test}
    pick = k = None
    for row in tef:
        if row["which"] != "tsc":
            continue
        md = np.asarray(recs[row["idx"]]["opf_maxdev"])
        cands = [kk for kk in range(len(md)) if row["cert"][kk] and md[kk] > np.pi]
        if cands:
            pick, k = row["idx"], cands[-1]; break
    r = recs[pick]
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 2.8))
    for ax, which, lab, col in [(axs[0], "opf", "(a) AC-OPF dispatch", "#e34948"), (axs[1], "tsc", "(b) TSC-OPF dispatch", "#2a78d6")]:
        st = B.g._state(r[which]["V"], r["Pd"], r["Qd"])
        t, V, Vcr, cert, margin, ok = energy_trace(B, st, r["Pd"], r["Qd"], k)
        ax.plot(t, V, color=col, lw=1.5, label=r"$r(t)$")
        if np.isfinite(Vcr):
            ax.axhline(Vcr, color="#333333", ls="--", lw=1, label=r"$r_{\mathrm{cr}}$ (PEBS)")
        ax.axvspan(0, B.conts[k].tc, color="#cccccc", alpha=0.5, lw=0)
        ax.set_xlabel("Time after fault (s)")
        ax.set_ylabel("Energy (p.u.·rad)")
        ax.set_title(f"{lab}: {'certified' if cert else 'not certified'} (margin {margin:+.2f})", fontsize=8.5)
        top = max(np.nanmax(V[: int(1.0 / 0.001)]), Vcr if np.isfinite(Vcr) else 0) * 1.3
        ax.set_ylim(min(0, V.min()) - 0.05 * top, top)
        ax.legend(fontsize=7, loc="upper right")
    i2e = B.g.ppc["order"]["bus"]["i2e"]
    c = B.conts[k]
    fig.suptitle(f"{name.replace('case', 'IEEE ')}-bus: transient energy (Lyapunov) function in COI deviation coordinates; "
                 f"fault at bus {int(i2e[c.bus])}, cleared at {c.tc:.2f} s (shaded)", fontsize=8)
    fig.tight_layout()
    fig.savefig(f"{OUT}/figures/fig_lyapunov_{name}.png")
    print("scenario", pick, "contingency", k)


if __name__ == "__main__":
    main(*(sys.argv[1:2] or ["case39"]))
