"""Conventional baselines that use the high-fidelity simulator in the loop.

TSC-OPF (iterative generation rescheduling): the classical engineering approach
to transient-stability-constrained OPF. Solve AC-OPF, simulate the critical
contingencies, and if any is insecure, cap the output of the advanced
(critical) machines and re-solve. Repeated until all contingencies are secure.
"""
import time
import numpy as np
from dynamics import simulate

DELTA_LIM = 2.0  # security limit on max |δ_g − δ_COI| (rad, ≈115°)


def critical_machines(grid, md, st, Pd, Qd, conts):
    """Advanced-group machines of each insecure contingency (from recorded trajectory)."""
    r = simulate(grid, md, st, Pd, Qd, conts, model="flux", record=True)
    dev = r["traj"][:, :, 0] - r["coi"][..., None]          # (T, K, ng)
    crit = np.zeros(grid.ng, bool)
    insecure = r["max_dev"] > DELTA_LIM
    for k in np.where(insecure)[0]:
        # time of first crossing of the security limit (or of the max)
        a = np.abs(dev[:, k]).max(1)
        ti = int(np.argmax(a > DELTA_LIM)) if (a > DELTA_LIM).any() else int(np.argmax(a))
        d = dev[ti, k]
        crit |= d > 0.5 * d.max()
    return r, insecure, crit


def tsc_opf(grid, md, Pd, Qd, conts, step=0.08, max_iter=15):
    t0 = time.perf_counter()
    Pmax = grid.Pmax.copy()
    st = grid.solve_opf(Pd, Qd)
    if st is None:
        return None
    opf = st
    n_opf, n_sim = 1, 0
    for it in range(max_iter):
        r, insecure, crit = critical_machines(grid, md, st, Pd, Qd, conts)
        n_sim += 1
        if not insecure.any():
            return dict(st=st, opf=opf, iters=it, n_opf=n_opf, n_sim=n_sim,
                        time=time.perf_counter() - t0, secure=True, max_dev=r["max_dev"])
        crit &= st["Pg"] > grid.Pmin + 1e-3
        if not crit.any():
            break
        new = None
        for s in (step, step / 2, step / 4):
            trial = Pmax.copy()
            trial[crit] = np.maximum(grid.Pmin[crit], st["Pg"][crit] - s * np.maximum(st["Pg"][crit], 0.5))
            new = grid.solve_opf(Pd, Qd, Pmax_override=trial)
            n_opf += 1
            if new is not None:
                Pmax = trial
                break
        if new is None:
            break
        st = new
    r = simulate(grid, md, st, Pd, Qd, conts, model="flux")
    return dict(st=st, opf=opf, iters=max_iter, n_opf=n_opf, n_sim=n_sim + 1,
                time=time.perf_counter() - t0, secure=bool(np.all(r["max_dev"] <= DELTA_LIM)),
                max_dev=r["max_dev"])
