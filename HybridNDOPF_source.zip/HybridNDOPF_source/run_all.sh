#!/bin/sh
# Full reproduction of the revised Hybrid ND-OPF experiments (CPU only, ~12 h on 2 cores).
set -e
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1
mkdir -p out/figures
for c in case39 case118; do
  python3 datagen.py $c 2                           # scenarios, AC-OPF, high-fidelity sim, TSC-OPF, trajectories
  python3 train_surrogate.py $c 15                  # physics-structured neural ODE
  T="python3 train_predictor.py $c --epochs 100 --stab_epochs 12"
  $T --tag mlp_opf    --model mlp --label opf
  $T --tag gnn_opf    --model gnn --label opf
  $T --tag mlp_tsc    --model mlp --label tsc
  $T --tag gnn_tsc    --model gnn --label tsc
  $T --tag mlp_tsc_pf --model mlp --label tsc --lam_pf 0.1
  $T --tag gnn_tsc_pf --model gnn --label tsc --lam_pf 0.1
  $T --tag mlp_lam0.3 --model mlp --label tsc --lam_pf 0.1 --lam_stab 0.3
  $T --tag mlp_full   --model mlp --label tsc --lam_pf 0.1 --lam_stab 1.0
  $T --tag gnn_full   --model gnn --label tsc --lam_pf 0.1 --lam_stab 1.0
  $T --tag gnn_full_cl --model gnn --label tsc --lam_pf 0.1 --lam_stab 1.0 --surrogate classical
done
# lambda sweep (39-bus GNN)
T="python3 train_predictor.py case39 --epochs 100 --stab_epochs 12 --model gnn --label tsc --lam_pf 0.1"
$T --tag gnn_lam0.3 --lam_stab 0.3
$T --tag gnn_lam3   --lam_stab 3.0
$T --tag gnn_lam10  --lam_stab 10.0
# validation-set backbone selection (no test data)
python3 select_backbone.py case39 mlp_tsc mlp_tsc_pf mlp_lam0.3 mlp_full gnn_tsc gnn_tsc_pf gnn_lam0.3 gnn_full gnn_lam3 gnn_lam10
python3 select_backbone.py case118 mlp_tsc mlp_tsc_pf mlp_lam0.3 mlp_full gnn_tsc gnn_tsc_pf gnn_full
for c in case39 case118; do
  python3 evaluate.py $c                           # all methods, test + OOD, high-fidelity re-simulation
  python3 tef_eval.py $c                           # Lyapunov / energy-function certificate validation
  python3 timing.py $c 40                          # single-thread latency benchmark
  python3 fig_dynamics.py $c
done
python3 experiments.py case39 sweep
python3 experiments.py case39 noise
python3 fig_lyapunov.py case39
python3 fig_residuals.py
python3 report.py                                  # out/RESULTS.md + figures
python3 final_tables.py                            # out/HEADLINE.md (certificate + fallback protocol)
python3 seeds.py case39 1 2                        # seed robustness
python3 seeds.py case118 1 2
python3 balance.py                                 # out/BALANCE.md + fig_pareto (CIs, expected cost)
