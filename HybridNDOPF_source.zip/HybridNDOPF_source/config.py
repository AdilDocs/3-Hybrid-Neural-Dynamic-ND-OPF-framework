"""Experiment configuration (single source of truth)."""
# Critical contingencies: three-phase bolted fault at internal bus index, cleared at
# tc by tripping the internal line index. Selected as the 5 most severe faults of
# an exhaustive screening of all non-islanding line faults at the nominal OPF point.
CFG = {
    "case39": dict(tc=0.15, conts=[(28, 44), (28, 43), (27, 44), (25, 43), (25, 42)],
                   load_in=(0.80, 1.04), load_ood=(1.04, 1.08),
                   n_in=1600, n_ood=150, n_traj=300, sdt=0.01, idt=0.025, Tscreen=1.5),
    "case118": dict(tc=0.22, conts=[(25, 31), (25, 37), (7, 36), (7, 7), (99, 154)],
                    load_in=(0.80, 1.20), load_ood=(1.20, 1.30),
                    n_in=1200, n_ood=120, n_traj=150, sdt=0.02, idt=0.0275, Tscreen=2.0),
}
LOCAL_SIGMA = 0.05   # per-bus multiplicative load noise
ROOT = "/home/claude/ndopf"
import os
OUT = os.environ.get("NDOPF_OUT", f"{ROOT}/out")
DATA_SUFFIX = os.environ.get("NDOPF_SUFFIX", "")
