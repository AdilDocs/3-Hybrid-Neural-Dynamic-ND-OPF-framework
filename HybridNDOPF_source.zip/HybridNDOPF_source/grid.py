"""Steady-state power-system core: case loading, AC power flow, AC-OPF reference,
and the AC feasibility-restoration (projection) layer.

All internal quantities are per-unit on baseMVA unless a name ends in _MW.
"""
import re
import time
import warnings
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
import osqp
import clarabel
from pypower.api import runopf, ppoption, ext2int
from pypower.makeYbus import makeYbus
from pypower.newtonpf import newtonpf
from pypower.dSbus_dV import dSbus_dV
from pypower.dSbr_dV import dSbr_dV
from pypower.idx_bus import PD, QD, VM, VA, BUS_TYPE, VMAX, VMIN, PQ, PV, REF, GS, BS
from pypower.idx_gen import GEN_BUS, PG, QG, VG, PMAX, PMIN, QMAX, QMIN, GEN_STATUS
from pypower.idx_brch import F_BUS, T_BUS, RATE_A, BR_STATUS

warnings.filterwarnings("ignore")


# --------------------------------------------------------------------------
# Case loading (MATPOWER .m files from PGLib-OPF)
# --------------------------------------------------------------------------
def load_matpower_m(path):
    txt = open(path).read()
    ppc = {"version": "2"}
    ppc["baseMVA"] = float(re.search(r"mpc\.baseMVA\s*=\s*([\d.]+)", txt).group(1))
    for key in ["bus", "gen", "branch", "gencost"]:
        block = re.search(r"mpc\.%s\s*=\s*\[(.*?)\];" % key, txt, re.S).group(1)
        rows = []
        for line in block.strip().split("\n"):
            line = line.split("%")[0].strip().rstrip(";").strip()
            if line:
                rows.append([float(v) for v in line.split()])
        ppc[key] = np.array(rows)
    return ppc


class Grid:
    """Holds a case in internal (consecutive) numbering plus fixed network matrices."""

    def __init__(self, path, name):
        self.name = name
        ppc = ext2int(load_matpower_m(path))
        self.ppc = ppc
        self.base = ppc["baseMVA"]
        bus, gen, br = ppc["bus"], ppc["gen"], ppc["branch"]
        self.nb, self.ng, self.nl = bus.shape[0], gen.shape[0], br.shape[0]
        self.Ybus, self.Yf, self.Yt = makeYbus(self.base, bus, br)
        self.Ybus = sp.csr_matrix(self.Ybus)
        self.f = br[:, F_BUS].astype(int)
        self.t = br[:, T_BUS].astype(int)
        self.rate = br[:, RATE_A] / self.base
        self.rate[self.rate <= 0] = np.inf
        self.gbus = gen[:, GEN_BUS].astype(int)
        self.ref = int(np.where(bus[:, BUS_TYPE] == REF)[0][0])
        self.pv = np.where(bus[:, BUS_TYPE] == PV)[0]
        self.pq = np.where(bus[:, BUS_TYPE] == PQ)[0]
        assert len(set(self.gbus)) == self.ng, "one generator per bus assumed"
        self.slack_gen = int(np.where(self.gbus == self.ref)[0][0])
        self.Pmax = gen[:, PMAX] / self.base
        self.Pmin = gen[:, PMIN] / self.base
        self.Qmax = gen[:, QMAX] / self.base
        self.Qmin = gen[:, QMIN] / self.base
        self.Vmax = bus[:, VMAX]
        self.Vmin = bus[:, VMIN]
        self.Pd0 = bus[:, PD] / self.base
        self.Qd0 = bus[:, QD] / self.base
        gc = ppc["gencost"]
        assert np.all(gc[:, 0] == 2) and np.all(gc[:, 3] == 3)
        self.c2, self.c1, self.c0 = gc[:, 4], gc[:, 5], gc[:, 6]  # $/h with Pg in MW
        # controllable set u = [Pg of non-slack gens, Vm of all gen buses]
        self.ctrl_gens = np.array([g for g in range(self.ng) if g != self.slack_gen])
        # edge list for GNN (undirected, unique pairs)
        pairs = {tuple(sorted((a, b))) for a, b in zip(self.f, self.t)}
        self.edges = np.array(sorted(pairs)).T

    # ---------------------------------------------------------------- cost
    def cost(self, Pg_pu):
        P = np.asarray(Pg_pu) * self.base
        return np.sum(self.c2 * P ** 2 + self.c1 * P + self.c0, axis=-1)

    # ---------------------------------------------------------- power flow
    def power_flow(self, Pg, Vg, Pd, Qd, V0=None, tol=1e-8, max_it=20):
        """Newton-Raphson AC power flow. Pg (ng,) pu for all gens (slack value is
        ignored), Vg (ng,) setpoints. Returns dict with complete AC state."""
        Sbus = -(Pd + 1j * Qd).astype(complex)
        Sbus[self.gbus] += Pg
        if V0 is None:
            V0 = np.ones(self.nb, complex)
        V0 = V0.copy()
        V0[self.gbus] = Vg * np.exp(1j * np.angle(V0[self.gbus]))
        # constant-shunt elements are inside Ybus via makeYbus (GS/BS)
        ppopt = ppoption(VERBOSE=0, PF_MAX_IT=max_it, PF_TOL=tol)
        V, success, it = newtonpf(self.Ybus, Sbus, V0, self.ref, self.pv, self.pq, ppopt)
        return self._state(V, Pd, Qd, success)

    def _state(self, V, Pd, Qd, success=True):
        Sinj = V * np.conj(self.Ybus @ V)
        Sg_bus = Sinj + Pd + 1j * Qd
        Pg = Sg_bus.real[self.gbus]
        Qg = Sg_bus.imag[self.gbus]
        Sf = V[self.f] * np.conj(self.Yf @ V)
        St = V[self.t] * np.conj(self.Yt @ V)
        return dict(V=V, Pg=Pg, Qg=Qg, Sf=Sf, St=St, success=bool(success))

    def kcl_residual(self, st, Pd, Qd):
        """Max nodal power-balance mismatch (pu) of an AC state."""
        V = st["V"]
        Sinj = V * np.conj(self.Ybus @ V)
        Sg = np.zeros(self.nb, complex)
        Sg[self.gbus] = st["Pg"] + 1j * st["Qg"]
        return np.abs(Sinj - (Sg - Pd - 1j * Qd))

    def violations(self, st):
        """Constraint violation vector (pu, >0 means violated) for an AC state."""
        Vm = np.abs(st["V"])
        v = dict(
            Pg=np.maximum(st["Pg"] - self.Pmax, 0) + np.maximum(self.Pmin - st["Pg"], 0),
            Qg=np.maximum(st["Qg"] - self.Qmax, 0) + np.maximum(self.Qmin - st["Qg"], 0),
            Vm=np.maximum(Vm - self.Vmax, 0) + np.maximum(self.Vmin - Vm, 0),
            Sl=np.maximum(np.maximum(np.abs(st["Sf"]), np.abs(st["St"])) - self.rate, 0),
        )
        return v

    def max_violation(self, st):
        return max(float(np.max(x)) if len(x) else 0.0 for x in self.violations(st).values())

    # ------------------------------------------------------ AC-OPF (IPM)
    def solve_opf(self, Pd, Qd, Pmax_override=None):
        """Reference AC-OPF with PYPOWER's primal-dual interior-point (PIPS)."""
        ppc = {k: (v.copy() if isinstance(v, np.ndarray) else v) for k, v in self.ppc.items() if k != "order"}
        ppc["bus"][:, PD] = Pd * self.base
        ppc["bus"][:, QD] = Qd * self.base
        if Pmax_override is not None:
            ppc["gen"][:, PMAX] = Pmax_override * self.base
        t0 = time.perf_counter()
        r = runopf(ppc, ppoption(VERBOSE=0, OUT_ALL=0))
        dt = time.perf_counter() - t0
        if not r["success"]:
            return None
        V = r["bus"][:, VM] * np.exp(1j * np.deg2rad(r["bus"][:, VA]))
        st = self._state(V, Pd, Qd)
        st.update(cost=float(r["f"]), time=dt, Vg=r["bus"][self.gbus, VM])
        return st

    # ------------------------------------------- feasibility restoration
    def restore(self, Pg_hat, Vg_hat, Pd, Qd, tol=1e-4, max_iter=15, margin=2e-4):
        """AC feasibility restoration = projection of the predicted setpoints
        u_hat=(Pg, Vg) onto the AC-feasible set, solved by sequential
        linearisation: each iteration (i) solves the full AC power flow exactly
        (KCL satisfied to 1e-8), (ii) linearises all operating limits w.r.t. u
        via the power-flow Jacobian (implicit-function theorem) and (iii) solves
        the projection QP  min ||u - u_hat||^2  s.t. linearised limits (OSQP).
        Returns final AC state + diagnostics."""
        t0 = time.perf_counter()
        cg = self.ctrl_gens
        u_hat = np.concatenate([Pg_hat[cg], Vg_hat])
        lo = np.concatenate([self.Pmin[cg], self.Vmin[self.gbus]])
        hi = np.concatenate([self.Pmax[cg], self.Vmax[self.gbus]])
        u = np.clip(u_hat, lo, hi)
        w = np.concatenate([np.ones(len(cg)), 4.0 * np.ones(self.ng)])  # Vm deviations weigh more
        hist, V = [], None
        Pg_full = np.array(Pg_hat, float).copy()
        nP = len(cg)
        tr = np.concatenate([0.5 * np.ones(nP), 0.03 * np.ones(self.ng)])  # trust region
        best = None
        u_prev, mv_prev = None, np.inf
        it = 0
        for it in range(max_iter + 1):
            Pg_full[cg] = u[:nP]
            st = self.power_flow(Pg_full, u[nP:], Pd, Qd, V0=None if best is None else best[0]["V"])
            if not st["success"]:
                st = self.power_flow(Pg_full, u[nP:], Pd, Qd, V0=None)
            mv = self.max_violation(st) if st["success"] else np.inf
            hist.append(mv)
            if mv > mv_prev and u_prev is not None:
                # reject step: shrink trust region and retry from previous point
                tr *= 0.4
                u = u_prev.copy()
                st, mv = best
                if it == max_iter:
                    break
            else:
                best = (st, mv)
                if mv <= tol:
                    return dict(st, success=True, iters=it, time=time.perf_counter() - t0, hist=hist,
                                Vg=np.abs(st["V"][self.gbus]), u=u)
                if it == max_iter:
                    break
                tr = np.minimum(tr * 1.5, np.concatenate([0.5 * np.ones(nP), 0.03 * np.ones(self.ng)]))
            u_prev, mv_prev = u.copy(), mv
            G, h = self._linearised_limits(st, margin)
            x = elastic_qp(w, u - u_hat, G, h, np.maximum(lo - u, -tr), np.minimum(hi - u, tr))
            if x is None:
                break
            u = np.clip(u + x, lo, hi)
        st, mv = best
        return dict(st, success=mv <= tol, iters=it, time=time.perf_counter() - t0, hist=hist,
                    Vg=np.abs(st["V"][self.gbus]), u=u)

    def _linearised_limits(self, st, margin):
        """Rows g(u)+G du <= -margin for every monitored limit (slack Pg, all Qg,
        PQ-bus |V|, branch |S|), using dx/du = -J_x^{-1} F_u."""
        V = st["V"]
        Vm = np.abs(V)
        cg = self.ctrl_gens
        pvpq = np.r_[self.pv, self.pq]
        dS_dVm, dS_dVa = dSbus_dV(self.Ybus, V)
        dS_dVm, dS_dVa = sp.csr_matrix(dS_dVm), sp.csr_matrix(dS_dVa)
        # state x = [Va(pvpq), Vm(pq)], equations F = [P(pvpq); Q(pq)]
        J = sp.vstack([
            sp.hstack([dS_dVa.real[pvpq][:, pvpq], dS_dVm.real[pvpq][:, self.pq]]),
            sp.hstack([dS_dVa.imag[self.pq][:, pvpq], dS_dVm.imag[self.pq][:, self.pq]]),
        ]).tocsc()
        nu = len(cg) + self.ng
        Fu = np.zeros((J.shape[0], nu))
        row_of_bus = {b: k for k, b in enumerate(pvpq)}
        for k, g in enumerate(cg):          # d(P_calc - P_spec)/dPg = -1
            Fu[row_of_bus[self.gbus[g]], k] = -1.0
        dVmg = dS_dVm[:, self.gbus].toarray()  # sensitivity to gen-bus Vm setpoints
        Fu[:, len(cg):] = np.vstack([dVmg.real[pvpq], dVmg.imag[self.pq]])
        dx = -spla.splu(J).solve(Fu)        # (nx, nu)
        dVa = np.zeros((self.nb, nu))
        dVm = np.zeros((self.nb, nu))
        dVa[pvpq] = dx[:len(pvpq)]
        dVm[self.pq] = dx[len(pvpq):]
        dVm[self.gbus, len(cg) + np.arange(self.ng)] = 1.0
        # bus injection sensitivities -> generator outputs
        dS = dS_dVa @ dVa + dS_dVm @ dVm   # (nb, nu) complex
        dPg = dS.real[self.gbus]
        dQg = dS.imag[self.gbus]
        for k, g in enumerate(cg):
            dPg[g, k] += 0.0  # Pg of PV gens is the control itself
        rows, rhs = [], []

        def add(val, grad, upper):
            viol = val - upper
            idx = np.where(viol > -0.05)[0]  # active set: violated or close
            for i in idx:
                rows.append(grad[i])
                rhs.append(-(viol[i]) - margin)

        sg = self.slack_gen
        add(st["Pg"][[sg]], dPg[[sg]], self.Pmax[[sg]])
        add(-st["Pg"][[sg]], -dPg[[sg]], -self.Pmin[[sg]])
        add(st["Qg"], dQg, self.Qmax)
        add(-st["Qg"], -dQg, -self.Qmin)
        add(Vm[self.pq], dVm[self.pq], self.Vmax[self.pq])
        add(-Vm[self.pq], -dVm[self.pq], -self.Vmin[self.pq])
        lim = np.isfinite(self.rate)
        if lim.any():
            dSf_dVa, dSf_dVm, dSt_dVa, dSt_dVm, Sf, St = dSbr_dV(
                self.ppc["branch"], self.Yf, self.Yt, V)
            for dVa_, dVm_, S in [(dSf_dVa, dSf_dVm, Sf), (dSt_dVa, dSt_dVm, St)]:
                dSbr = sp.csr_matrix(dVa_) @ dVa + sp.csr_matrix(dVm_) @ dVm
                absS = np.abs(S)
                # d|S| = Re(conj(S) dS)/|S|
                g = (np.conj(S)[:, None] * dSbr).real / np.maximum(absS, 1e-9)[:, None]
                il = np.where(lim)[0]
                add(absS[il], g[il], self.rate[il])
        if not rows:
            return np.zeros((0, nu)), np.zeros(0)
        return np.array(rows), np.array(rhs)


def elastic_qp(w, d, G, h, lb, ub, rho=1e4):
    """min sum w (d+x)^2 + rho*(sum s + sum s^2)  s.t. G x - s <= h, s>=0, lb<=x<=ub.
    Solved with the Clarabel interior-point solver. Returns x or None."""
    n, m = len(d), len(h)
    N = n + m
    P = sp.block_diag([sp.diags(2 * w), sp.diags(2 * rho * np.ones(m))], format="csc") if m else sp.diags(2 * w, format="csc")
    q = np.concatenate([2 * w * d, rho * np.ones(m)])
    blocks, b = [], []
    if m:
        blocks.append(sp.hstack([sp.csc_matrix(G), -sp.eye(m)])); b.append(h)
        blocks.append(sp.hstack([sp.csc_matrix((m, n)), -sp.eye(m)])); b.append(np.zeros(m))
    E = sp.hstack([sp.eye(n), sp.csc_matrix((n, m))])
    blocks += [E, -E]; b += [ub, -lb]
    A = sp.vstack(blocks, format="csc")
    bb = np.concatenate(b)
    st = clarabel.DefaultSettings(); st.verbose = False
    sol = clarabel.DefaultSolver(sp.triu(P, format="csc"), q, A, bb, [clarabel.NonnegativeConeT(len(bb))], st)
    r = sol.solve()
    if str(r.status) not in ("Solved", "AlmostSolved"):
        return None
    return np.array(r.x[:n])


CASES = {
    "case39": "data/raw/pglib_opf_case39_epri.m",
    "case118": "data/raw/pglib_opf_case118_ieee.m",
}


def load_grid(name, root="/home/claude/ndopf"):
    return Grid(f"{root}/{CASES[name]}", name)
